# Overview

This is a French grammar learning application designed for 7th-grade students. It's a full-stack web application built with React and Express that provides interactive lessons and exercises for learning French grammar concepts. The app features multiple exercise types including multiple choice questions, fill-in-the-blanks, drag-and-drop, and matching activities, all focused on French articles and grammar rules.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The frontend is built with **React 18** using TypeScript and follows a modern component-based architecture:

- **Routing**: Uses Wouter for client-side routing, providing a lightweight alternative to React Router
- **State Management**: Leverages React Query (@tanstack/react-query) for server state management and caching
- **UI Framework**: Built with shadcn/ui components based on Radix UI primitives, providing accessible and customizable components
- **Styling**: Uses Tailwind CSS with custom CSS variables for theming, supporting both light and dark modes
- **Build Tool**: Vite for fast development and optimized production builds

The application structure separates concerns with dedicated directories for components, pages, hooks, and utilities. Exercise components are modularized for different types of learning activities.

## Backend Architecture

The backend uses **Express.js** with TypeScript in a lightweight REST API pattern:

- **Server Framework**: Express.js with middleware for JSON parsing and request logging
- **Database Layer**: Prepared for Drizzle ORM with PostgreSQL through the Neon serverless driver
- **Storage Interface**: Implements a storage abstraction with both in-memory and database implementations
- **Development Setup**: Includes Vite middleware integration for seamless full-stack development

The server follows a modular route registration pattern and includes proper error handling middleware.

## Data Storage Solutions

The application is configured for **PostgreSQL** using:

- **ORM**: Drizzle ORM for type-safe database operations
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema Management**: Centralized schema definitions with Zod validation
- **Development Storage**: In-memory storage implementation for development and testing

The schema currently defines a users table with UUID primary keys and includes proper TypeScript type generation.

## Authentication and Authorization

The foundation for authentication is prepared with:

- **Session Management**: Connect-pg-simple for PostgreSQL-backed sessions
- **User Schema**: Basic user table with username/password fields
- **Storage Interface**: User CRUD operations abstracted for easy implementation

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Query for state management
- **Backend**: Express.js, Node.js runtime
- **Database**: Drizzle ORM, Neon Database serverless driver, PostgreSQL

### UI and Styling
- **Component Library**: Radix UI primitives for accessible components
- **Styling**: Tailwind CSS with PostCSS processing
- **Icons**: Font Awesome 6.4.0, Lucide React icons
- **Fonts**: Google Fonts (Inter, Geist Mono, DM Sans, Fira Code, Architects Daughter)

### Development Tools
- **Build Tools**: Vite, esbuild for production builds
- **TypeScript**: Full TypeScript support across frontend and backend
- **Development**: tsx for TypeScript execution, Replit integration plugins

### Validation and Forms
- **Schema Validation**: Zod for runtime type validation
- **Form Handling**: React Hook Form with Hookform resolvers
- **Data Validation**: Drizzle-zod for database schema validation

The application is designed to be easily deployable on Replit with proper environment variable configuration for the database connection.