import { useRoute, Link } from "wouter";
import { topics } from "@/data/topics";
import { useState } from "react";
import MultipleChoice from "@/components/exercises/multiple-choice";
import FillInBlanks from "@/components/exercises/fill-in-blanks";
import DragDrop from "@/components/exercises/drag-drop";
import Matching from "@/components/exercises/matching";
import PDFGenerator from "@/components/pdf-generator";

export default function Topic() {
  const [, params] = useRoute("/topic/:topicId");
  const topicId = params?.topicId;
  const [generatingPDF, setGeneratingPDF] = useState(false);
  
  const topic = topics.find(t => t.id === topicId);
  
  if (!topic) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">Thema nicht gefunden</h1>
          <Link href="/">
            <button className="bg-primary text-primary-foreground px-6 py-2 rounded-lg">
              Zurück zur Startseite
            </button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="bg-card shadow-sm border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <i className="fas fa-graduation-cap text-primary text-2xl"></i>
              <h1 className="text-xl font-semibold text-foreground">Französisch Grammatik</h1>
            </div>
            <div className="text-sm text-muted-foreground">
              7. Klasse
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Link href="/">
              <button className="hover:text-primary cursor-pointer" data-testid="breadcrumb-home">
                <i className="fas fa-home"></i> Startseite
              </button>
            </Link>
            <i className="fas fa-chevron-right text-xs"></i>
            <span className="text-foreground">{topic.title}</span>
          </div>
        </nav>

        {/* Topic Header */}
        <div className="bg-card rounded-lg border border-border p-8 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <div className={`w-16 h-16 ${topic.bgColor} rounded-lg flex items-center justify-center mr-6`}>
                <i className={`${topic.icon} ${topic.iconColor} text-2xl`}></i>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">{topic.explanation.title}</h1>
                <p className="text-muted-foreground">{topic.subtitle}</p>
                <span className={`inline-block mt-2 text-xs px-3 py-1 rounded-full ${
                  topic.level === 'anfänger' ? 'bg-green-100 text-green-800' :
                  topic.level === 'mittelstufe' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {topic.level}
                </span>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <PDFGenerator 
                topic={topic} 
                onGenerating={setGeneratingPDF}
              />
              {generatingPDF && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <i className="fas fa-spinner fa-spin"></i>
                  PDF wird erstellt...
                </div>
              )}
            </div>
          </div>

          {/* Explanation Section */}
          <div className="prose max-w-none">
            <h3 className="text-xl font-semibold text-foreground mb-4">Erklärung</h3>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              {topic.explanation.introduction}
            </p>
            
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              {topic.explanation.content.map((section, index) => (
                <div key={index} className="bg-secondary rounded-lg p-6">
                  <h4 className="font-semibold text-foreground mb-3">{section.title}</h4>
                  <p className="text-sm text-muted-foreground mb-4">{section.description}</p>
                  <div className="space-y-2 text-sm">
                    {section.items.map((item, itemIndex) => (
                      <div key={itemIndex} className="flex justify-between">
                        <span className="font-medium">{item.label}</span>
                        <span className="text-primary font-semibold">{item.value}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 text-xs text-muted-foreground">
                    {section.examples}
                  </div>
                  {section.detailedExamples && (
                    <div className="mt-4 space-y-2">
                      {section.detailedExamples.map((example, exampleIndex) => (
                        <div key={exampleIndex} className="text-xs">
                          <div className="font-medium text-foreground">{example.french}</div>
                          <div className="text-muted-foreground">{example.german}</div>
                        </div>
                      ))}
                    </div>
                  )}
                  {section.rules && (
                    <div className="mt-4">
                      <h5 className="text-sm font-medium text-foreground mb-2">Wichtige Regeln:</h5>
                      <ul className="text-xs text-muted-foreground space-y-1">
                        {section.rules.map((rule, ruleIndex) => (
                          <li key={ruleIndex}>• {rule}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Exercises Section */}
        <div className="space-y-8">
          {/* Exercise 1: Multiple Choice */}
          <MultipleChoice 
            exercise={topic.exercises.multipleChoice}
            exerciseNumber={1}
          />

          {/* Exercise 2: Fill in the Blanks */}
          <FillInBlanks 
            exercise={topic.exercises.fillInBlanks}
            exerciseNumber={2}
          />

          {/* Exercise 3: Drag & Drop */}
          <DragDrop 
            exercise={topic.exercises.dragDrop}
            exerciseNumber={3}
          />

          {/* Exercise 4: Matching */}
          <Matching 
            exercise={topic.exercises.matching}
            exerciseNumber={4}
          />
        </div>

        {/* Navigation */}
        <div className="flex justify-between mt-12">
          <Link href="/">
            <button 
              className="bg-secondary text-secondary-foreground px-6 py-3 rounded-lg hover:bg-secondary/80 transition-colors"
              data-testid="button-back-home"
            >
              <i className="fas fa-arrow-left mr-2"></i>
              Zurück zur Übersicht
            </button>
          </Link>
          <button 
            className="bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors"
            data-testid="button-next-topic"
          >
            Nächstes Thema
            <i className="fas fa-arrow-right ml-2"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
