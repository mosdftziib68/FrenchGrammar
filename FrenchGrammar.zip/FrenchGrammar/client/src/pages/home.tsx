import { Link } from "wouter";
import { topics } from "@/data/topics";
import { useState, useMemo } from "react";
import { Input } from "@/components/ui/input";

export default function Home() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedLevel, setSelectedLevel] = useState<string>("all");

  const filteredTopics = useMemo(() => {
    return topics.filter(topic => {
      const matchesSearch = 
        topic.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        topic.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        topic.keywords.some(keyword => 
          keyword.toLowerCase().includes(searchTerm.toLowerCase())
        );
      
      const matchesLevel = selectedLevel === "all" || topic.level === selectedLevel;
      
      return matchesSearch && matchesLevel;
    });
  }, [searchTerm, selectedLevel]);

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="bg-card shadow-sm border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <i className="fas fa-graduation-cap text-primary text-2xl"></i>
              <h1 className="text-xl font-semibold text-foreground">Französisch Grammatik</h1>
            </div>
            <div className="text-sm text-muted-foreground">
              7. Klasse
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">
            Französische Grammatik lernen
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Entdecke die französische Grammatik mit einfachen Erklärungen und interaktiven Übungen. 
            Perfekt für die 7. Klasse!
          </p>
          
          {/* Search and Filter Section */}
          <div className="max-w-4xl mx-auto mb-8">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-center">
              <div className="relative flex-1 max-w-md">
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"></i>
                <Input
                  type="text"
                  placeholder="Themen durchsuchen..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="search-input"
                />
              </div>
              <select
                value={selectedLevel}
                onChange={(e) => setSelectedLevel(e.target.value)}
                className="px-4 py-2 border border-border rounded-lg bg-background text-foreground"
                data-testid="level-filter"
              >
                <option value="all">Alle Niveaus</option>
                <option value="anfänger">Anfänger</option>
                <option value="mittelstufe">Mittelstufe</option>
                <option value="fortgeschritten">Fortgeschritten</option>
              </select>
            </div>
            
            {/* Search Results Info */}
            <div className="mt-4 text-sm text-muted-foreground">
              {searchTerm || selectedLevel !== "all" ? (
                <p>
                  {filteredTopics.length} von {topics.length} Themen gefunden
                  {searchTerm && ` für "${searchTerm}"`}
                  {selectedLevel !== "all" && ` (${selectedLevel})`}
                </p>
              ) : (
                <p>{topics.length} Grammatik-Themen verfügbar</p>
              )}
            </div>
          </div>
        </div>

        {/* Topics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTopics.length > 0 ? (
            filteredTopics.map((topic) => (
              <Link key={topic.id} href={`/topic/${topic.id}`}>
                <div 
                  className="topic-card bg-card rounded-lg border border-border p-6 cursor-pointer"
                  data-testid={`topic-card-${topic.id}`}
                >
                  <div className="flex items-center mb-4">
                    <div className={`w-12 h-12 ${topic.bgColor} rounded-lg flex items-center justify-center mr-4`}>
                      <i className={`${topic.icon} ${topic.iconColor} text-xl`}></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-foreground">{topic.title}</h3>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        topic.level === 'anfänger' ? 'bg-green-100 text-green-800' :
                        topic.level === 'mittelstufe' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {topic.level}
                      </span>
                    </div>
                  </div>
                  <p className="text-muted-foreground text-sm mb-3">
                    {topic.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-primary text-sm font-medium">
                      <span>Jetzt lernen</span>
                      <i className="fas fa-arrow-right ml-2"></i>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {topic.keywords.slice(0, 3).join(", ")}
                    </div>
                  </div>
                </div>
              </Link>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <i className="fas fa-search text-6xl text-muted-foreground mb-4"></i>
              <h3 className="text-xl font-semibold text-foreground mb-2">
                Keine Themen gefunden
              </h3>
              <p className="text-muted-foreground">
                Versuche es mit anderen Suchbegriffen oder wähle ein anderes Niveau.
              </p>
              <button
                onClick={() => {
                  setSearchTerm("");
                  setSelectedLevel("all");
                }}
                className="mt-4 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
                data-testid="clear-search"
              >
                Suche zurücksetzen
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-16 text-muted-foreground text-sm">
          <p>© 2024 Französisch Grammatik Lernen - Perfekt für die 7. Klasse</p>
        </div>
      </div>
    </div>
  );
}