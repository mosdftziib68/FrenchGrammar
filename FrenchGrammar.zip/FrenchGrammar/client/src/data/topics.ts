export interface TopicData {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  icon: string;
  iconColor: string;
  bgColor: string;
  level: 'anfänger' | 'mittelstufe' | 'fortgeschritten';
  keywords: string[];
  explanation: {
    title: string;
    introduction: string;
    content: Array<{
      title: string;
      description: string;
      items: Array<{
        label: string;
        value: string;
        explanation?: string;
      }>;
      examples: string;
      detailedExamples?: Array<{
        french: string;
        german: string;
        explanation: string;
      }>;
      rules?: string[];
    }>;
  };
  exercises: {
    multipleChoice: {
      question: string;
      sentence: string;
      options: string[];
      correct: number;
      explanation: string;
    };
    fillInBlanks: {
      questions: Array<{
        sentence: string;
        answer: string;
      }>;
    };
    dragDrop: {
      articles: string[];
      words: Array<{
        word: string;
        correct: string;
      }>;
    };
    matching: {
      articles: string[];
      words: Array<{
        word: string;
        translation: string;
        correct: string;
      }>;
    };
  };
}

export const topics: TopicData[] = [
  {
    id: "articles-definite",
    title: "Bestimmte Artikel",
    subtitle: "le, la, les - die bestimmten Artikel",
    description: "Bestimmte Artikel: le (der), la (die), les (die Plural)",
    icon: "fas fa-tags",
    iconColor: "text-primary",
    bgColor: "bg-primary/10",
    level: "anfänger",
    keywords: ["artikel", "le", "la", "les", "bestimmt", "der", "die", "das"],
    explanation: {
      title: "Bestimmte Artikel im Französischen",
      introduction: "Die bestimmten Artikel gehören zu den fundamentalsten und wichtigsten Elementen der französischen Grammatik und sind für jeden Französischlernenden von entscheidender Bedeutung. Sie stehen immer vor Substantiven und haben die wichtige Funktion, das grammatikalische Geschlecht (Genre) - männlich oder weiblich - sowie die Zahl (Nombre) - Singular oder Plural - des nachfolgenden Substantivs anzuzeigen. Im Gegensatz zum Deutschen, wo es drei Geschlechter gibt (männlich, weiblich, sächlich), kennt das Französische nur zwei Geschlechter: männlich (masculin) und weiblich (féminin). Diese Vereinfachung macht das Erlernen der Artikel zunächst einfacher, jedoch müssen Deutschsprachige besonders aufpassen, da das Geschlecht französischer Substantive oft nicht mit dem deutschen übereinstimmt. Die bestimmten Artikel entsprechen im Deutschen 'der', 'die' und 'das', wobei 'das' im Französischen nicht existiert. Ein weiterer wichtiger Aspekt ist, dass die bestimmten Artikel im Französischen viel häufiger verwendet werden als im Deutschen und in vielen Kontexten obligatorisch sind, wo sie im Deutschen weggelassen werden können. Darüber hinaus verschmelzen sie mit bestimmten Präpositionen, was zu Kontraktionen führt, die unbedingt beherrscht werden müssen.",
      content: [
        {
          title: "Die drei bestimmten Artikel",
          description: "Im Französischen gibt es nur drei bestimmte Artikel, da es kein Neutrum gibt.",
          items: [
            { 
              label: "männlich Singular:", 
              value: "le", 
              explanation: "Wird vor männlichen Substantiven verwendet" 
            },
            { 
              label: "weiblich Singular:", 
              value: "la", 
              explanation: "Wird vor weiblichen Substantiven verwendet" 
            },
            { 
              label: "Plural (m. + w.):", 
              value: "les", 
              explanation: "Wird vor allen Substantiven im Plural verwendet" 
            }
          ],
          examples: "Grundformen: le garçon, la fille, les enfants",
          detailedExamples: [
            {
              french: "le livre",
              german: "das Buch",
              explanation: "männlich - daher 'le'"
            },
            {
              french: "la maison",
              german: "das Haus",
              explanation: "weiblich - daher 'la'"
            },
            {
              french: "les voitures",
              german: "die Autos",
              explanation: "Plural - immer 'les'"
            }
          ],
          rules: [
            "Vor Vokal oder stummem h wird 'le' und 'la' zu 'l'' verkürzt",
            "Der Artikel richtet sich nach dem Geschlecht des französischen Substantivs, nicht nach dem deutschen",
            "Im Plural gibt es keine Geschlechtsunterschiede"
          ]
        },
        {
          title: "Verschmelzung mit Präpositionen",
          description: "Bestimmte Artikel verschmelzen mit den Präpositionen 'à' und 'de'.",
          items: [
            { label: "à + le:", value: "au", explanation: "Beispiel: au cinéma (ins Kino)" },
            { label: "à + les:", value: "aux", explanation: "Beispiel: aux enfants (den Kindern)" },
            { label: "de + le:", value: "du", explanation: "Beispiel: du père (des Vaters)" },
            { label: "de + les:", value: "des", explanation: "Beispiel: des professeurs (der Lehrer)" }
          ],
          examples: "Verschmelzungen: au restaurant, aux États-Unis, du directeur, des élèves",
          rules: [
            "'à + la' und 'de + la' verschmelzen NICHT",
            "'à + l'' und 'de + l'' verschmelzen NICHT",
            "Diese Verschmelzungen sind obligatorisch"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wähle den richtigen bestimmten Artikel:",
        sentence: "___ professeur explique ___ leçon.",
        options: ["le / la", "la / le", "les / la"],
        correct: 0,
        explanation: "le professeur (männlich) / la leçon (weiblich)"
      },
      fillInBlanks: {
        questions: [
          { sentence: "___ école est grande.", answer: "L'" },
          { sentence: "___ livres sont intéressants.", answer: "Les" },
          { sentence: "___ chien aboie.", answer: "Le" }
        ]
      },
      dragDrop: {
        articles: ["le", "la", "les", "l'"],
        words: [
          { word: "université", correct: "l'" },
          { word: "étudiants", correct: "les" },
          { word: "professeur", correct: "le" }
        ]
      },
      matching: {
        articles: ["au", "aux", "du", "des"],
        words: [
          { word: "cinéma", translation: "ins Kino", correct: "au" },
          { word: "enfants", translation: "den Kindern", correct: "aux" },
          { word: "directeur", translation: "des Direktors", correct: "du" }
        ]
      }
    }
  },
  {
    id: "articles-indefinite",
    title: "Unbestimmte Artikel",
    subtitle: "un, une, des - die unbestimmten Artikel",
    description: "Unbestimmte Artikel: un (ein), une (eine), des (einige)",
    icon: "fas fa-question",
    iconColor: "text-accent",
    bgColor: "bg-accent/10",
    level: "anfänger",
    keywords: ["artikel", "un", "une", "des", "unbestimmt", "ein", "eine"],
    explanation: {
      title: "Unbestimmte Artikel im Französischen",
      introduction: "Die unbestimmten Artikel stehen vor Substantiven, die nicht näher bestimmt sind. Sie entsprechen dem deutschen 'ein', 'eine' im Singular und 'einige' oder gar keinem Artikel im Plural.",
      content: [
        {
          title: "Die drei unbestimmten Artikel",
          description: "Wie bei den bestimmten Artikeln gibt es auch hier drei Formen.",
          items: [
            { 
              label: "männlich Singular:", 
              value: "un", 
              explanation: "Wird vor männlichen Substantiven verwendet" 
            },
            { 
              label: "weiblich Singular:", 
              value: "une", 
              explanation: "Wird vor weiblichen Substantiven verwendet" 
            },
            { 
              label: "Plural (m. + w.):", 
              value: "des", 
              explanation: "Wird vor allen Substantiven im Plural verwendet" 
            }
          ],
          examples: "Grundformen: un ami, une amie, des amis",
          detailedExamples: [
            {
              french: "un professeur",
              german: "ein Lehrer",
              explanation: "männlich - daher 'un'"
            },
            {
              french: "une voiture",
              german: "ein Auto",
              explanation: "weiblich - daher 'une'"
            },
            {
              french: "des livres",
              german: "Bücher/einige Bücher",
              explanation: "Plural - immer 'des'"
            }
          ],
          rules: [
            "Nach Verneinung wird 'des' zu 'de' oder 'd''",
            "Nach Mengenangaben entfällt der unbestimmte Artikel",
            "Bei Berufsangaben kann der Artikel oft weggelassen werden"
          ]
        },
        {
          title: "Besonderheiten der unbestimmten Artikel",
          description: "Spezielle Regeln für die Verwendung der unbestimmten Artikel.",
          items: [
            { label: "Nach Verneinung:", value: "de/d'", explanation: "Je n'ai pas de voiture" },
            { label: "Nach Mengenangaben:", value: "de/d'", explanation: "beaucoup de livres" },
            { label: "Bei Berufen:", value: "oft ohne", explanation: "Il est professeur" }
          ],
          examples: "Besonderheiten: pas de problème, beaucoup d'amis, elle est médecin",
          rules: [
            "Vor Vokal bleibt 'des' erhalten: des élèves",
            "Nach 'de' entfällt der unbestimmte Artikel",
            "Bei abstrakten Begriffen oft ohne Artikel"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wähle den richtigen unbestimmten Artikel:",
        sentence: "Il y a ___ pomme et ___ oranges.",
        options: ["une / des", "un / des", "une / de"],
        correct: 0,
        explanation: "une pomme (weiblich) / des oranges (Plural)"
      },
      fillInBlanks: {
        questions: [
          { sentence: "J'ai ___ chien.", answer: "un" },
          { sentence: "Elle achète ___ robe.", answer: "une" },
          { sentence: "Nous voyons ___ oiseaux.", answer: "des" }
        ]
      },
      dragDrop: {
        articles: ["un", "une", "des", "de"],
        words: [
          { word: "problème", correct: "un" },
          { word: "solution", correct: "une" },
          { word: "difficultés", correct: "des" }
        ]
      },
      matching: {
        articles: ["un", "une", "des"],
        words: [
          { word: "étudiant", translation: "ein Student", correct: "un" },
          { word: "étudiante", translation: "eine Studentin", correct: "une" },
          { word: "étudiants", translation: "Studenten", correct: "des" }
        ]
      }
    }
  },
  {
    id: "pronouns-personal",
    title: "Personalpronomen",
    subtitle: "je, tu, il/elle/on, nous, vous, ils/elles",
    description: "Die Personalpronomen als Subjekt des Satzes",
    icon: "fas fa-user",
    iconColor: "text-blue-500",
    bgColor: "bg-topic-blue",
    level: "anfänger",
    keywords: ["pronomen", "je", "tu", "il", "elle", "nous", "vous", "ils", "elles", "personen"],
    explanation: {
      title: "Personalpronomen im Französischen",
      introduction: "Personalpronomen ersetzen Personen oder Dinge und stehen meist vor dem Verb. Sie zeigen an, wer die Handlung ausführt.",
      content: [
        {
          title: "Die Personalpronomen im Singular",
          description: "Im Singular gibt es vier verschiedene Personalpronomen.",
          items: [
            { 
              label: "1. Person:", 
              value: "je (j')", 
              explanation: "ich - wird vor Vokal zu j'" 
            },
            { 
              label: "2. Person:", 
              value: "tu", 
              explanation: "du - informelle Anrede" 
            },
            { 
              label: "3. Person männlich:", 
              value: "il", 
              explanation: "er - für männliche Personen/Dinge" 
            },
            { 
              label: "3. Person weiblich:", 
              value: "elle", 
              explanation: "sie - für weibliche Personen/Dinge" 
            },
            { 
              label: "3. Person unpersönlich:", 
              value: "on", 
              explanation: "man - unpersönliches Pronomen" 
            }
          ],
          examples: "Singular: je parle, tu parles, il/elle parle, on parle",
          detailedExamples: [
            {
              french: "Je suis étudiant",
              german: "Ich bin Student",
              explanation: "'je' wird vor Konsonanten verwendet"
            },
            {
              french: "J'habite à Paris",
              german: "Ich wohne in Paris",
              explanation: "'j'' wird vor Vokalen verwendet"
            },
            {
              french: "Tu es gentil",
              german: "Du bist nett",
              explanation: "'tu' für informelle Anrede (Duzen)"
            }
          ],
          rules: [
            "'je' wird vor Vokal oder stummem h zu 'j''",
            "'tu' wird nur bei vertrauten Personen verwendet",
            "'on' wird konjugiert wie 'il/elle' (3. Person Singular)"
          ]
        },
        {
          title: "Die Personalpronomen im Plural",
          description: "Im Plural gibt es drei Personalpronomen.",
          items: [
            { 
              label: "1. Person:", 
              value: "nous", 
              explanation: "wir - erste Person Plural" 
            },
            { 
              label: "2. Person:", 
              value: "vous", 
              explanation: "ihr/Sie - Plural oder höfliche Anrede" 
            },
            { 
              label: "3. Person männlich:", 
              value: "ils", 
              explanation: "sie (männlich oder gemischt)" 
            },
            { 
              label: "3. Person weiblich:", 
              value: "elles", 
              explanation: "sie (ausschließlich weiblich)" 
            }
          ],
          examples: "Plural: nous parlons, vous parlez, ils/elles parlent",
          detailedExamples: [
            {
              french: "Nous habitons en France",
              german: "Wir wohnen in Frankreich",
              explanation: "'nous' für die erste Person Plural"
            },
            {
              french: "Vous êtes sympathiques",
              german: "Ihr seid/Sie sind nett",
              explanation: "'vous' für Plural oder höfliche Anrede"
            },
            {
              french: "Ils sont contents",
              german: "Sie sind zufrieden",
              explanation: "'ils' wenn mindestens eine männliche Person dabei ist"
            }
          ],
          rules: [
            "'vous' wird sowohl für Plural als auch für höfliche Anrede verwendet",
            "'ils' wird verwendet, wenn mindestens eine männliche Person dabei ist",
            "'elles' nur wenn ausschließlich weibliche Personen gemeint sind"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welches Pronomen passt?",
        sentence: "___ êtes très gentils.",
        options: ["tu", "vous", "ils"],
        correct: 1,
        explanation: "vous êtes ist korrekt für die höfliche Anrede oder Plural."
      },
      fillInBlanks: {
        questions: [
          { sentence: "___ suis étudiant.", answer: "Je" },
          { sentence: "___ avez un chien?", answer: "Vous" },
          { sentence: "___ sont mes amis.", answer: "Ils" }
        ]
      },
      dragDrop: {
        articles: ["je", "tu", "il", "nous", "vous", "elles"],
        words: [
          { word: "parle (ich spreche)", correct: "je" },
          { word: "mangent (sie essen)", correct: "elles" },
          { word: "êtes (ihr seid)", correct: "vous" }
        ]
      },
      matching: {
        articles: ["tu", "nous", "elle"],
        words: [
          { word: "chantes", translation: "du singst", correct: "tu" },
          { word: "danse", translation: "sie tanzt", correct: "elle" },
          { word: "habitons", translation: "wir wohnen", correct: "nous" }
        ]
      }
    }
  },
  {
    id: "verbs-er-regular",
    title: "Regelmäßige -er Verben",
    subtitle: "Präsens der regelmäßigen Verben auf -er",
    description: "Konjugation der häufigsten Verbgruppe im Französischen",
    icon: "fas fa-play",
    iconColor: "text-green-500",
    bgColor: "bg-topic-green",
    level: "anfänger",
    keywords: ["verben", "konjugation", "-er", "präsens", "regelmäßig", "parler", "habiter"],
    explanation: {
      title: "Regelmäßige Verben auf -er",
      introduction: "Die Verben auf -er bilden die größte und regelmäßigste Verbgruppe im Französischen. Sie folgen alle dem gleichen Konjugationsmuster.",
      content: [
        {
          title: "Konjugationsmuster am Beispiel 'parler' (sprechen)",
          description: "So werden alle regelmäßigen -er Verben konjugiert.",
          items: [
            { label: "je", value: "parle", explanation: "Stamm + e" },
            { label: "tu", value: "parles", explanation: "Stamm + es" },
            { label: "il/elle/on", value: "parle", explanation: "Stamm + e" },
            { label: "nous", value: "parlons", explanation: "Stamm + ons" },
            { label: "vous", value: "parlez", explanation: "Stamm + ez" },
            { label: "ils/elles", value: "parlent", explanation: "Stamm + ent" }
          ],
          examples: "Konjugation: je parle, tu parles, il parle, nous parlons, vous parlez, ils parlent",
          detailedExamples: [
            {
              french: "Je parle français",
              german: "Ich spreche Französisch",
              explanation: "1. Person Singular: Stamm 'parl' + Endung 'e'"
            },
            {
              french: "Nous habitons à Berlin",
              german: "Wir wohnen in Berlin",
              explanation: "1. Person Plural: Stamm 'habit' + Endung 'ons'"
            },
            {
              french: "Ils regardent la télé",
              german: "Sie schauen fern",
              explanation: "3. Person Plural: Stamm 'regard' + Endung 'ent'"
            }
          ],
          rules: [
            "Der Stamm ist der Infinitiv ohne -er",
            "Die Endungen sind immer gleich: -e, -es, -e, -ons, -ez, -ent",
            "Je, tu, il/elle und ils/elles werden gleich ausgesprochen"
          ]
        },
        {
          title: "Häufige regelmäßige -er Verben",
          description: "Diese Verben folgen alle dem gleichen Muster.",
          items: [
            { label: "habiter", value: "wohnen", explanation: "j'habite, tu habites, etc." },
            { label: "travailler", value: "arbeiten", explanation: "je travaille, tu travailles, etc." },
            { label: "étudier", value: "studieren", explanation: "j'étudie, tu étudies, etc." },
            { label: "manger", value: "essen", explanation: "je mange, tu manges, etc." },
            { label: "regarder", value: "schauen", explanation: "je regarde, tu regardes, etc." },
            { label: "écouter", value: "hören", explanation: "j'écoute, tu écoutes, etc." }
          ],
          examples: "Weitere Verben: aimer (mögen), détester (hassen), chercher (suchen)",
          rules: [
            "Über 90% aller französischen Verben gehören zu dieser Gruppe",
            "Neue Verben werden meist nach diesem Muster gebildet",
            "Bei Verben auf -ger wird vor o und a ein e eingefügt (nous mangeons)"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Konjugiere das Verb 'chanter':",
        sentence: "Nous ___ bien.",
        options: ["chantons", "chantez", "chantent"],
        correct: 0,
        explanation: "nous chantons ist die richtige Form für 'wir'."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Tu ___ la télévision. (regarder)", answer: "regardes" },
          { sentence: "Elle ___ très bien. (danser)", answer: "danse" },
          { sentence: "Ils ___ au restaurant. (manger)", answer: "mangent" }
        ]
      },
      dragDrop: {
        articles: ["parle", "parles", "parlons", "parlez", "parlent"],
        words: [
          { word: "je", correct: "parle" },
          { word: "vous", correct: "parlez" },
          { word: "elles", correct: "parlent" }
        ]
      },
      matching: {
        articles: ["regardes", "dansons", "chantent"],
        words: [
          { word: "tu", translation: "du schaust", correct: "regardes" },
          { word: "nous", translation: "wir tanzen", correct: "dansons" },
          { word: "ils", translation: "sie singen", correct: "chantent" }
        ]
      }
    }
  },
  {
    id: "verbs-etre",
    title: "Das Verb être (sein)",
    subtitle: "Das wichtigste Hilfsverb im Französischen",
    description: "Konjugation und Verwendung von être (sein)",
    icon: "fas fa-star",
    iconColor: "text-yellow-500",
    bgColor: "bg-topic-yellow",
    level: "anfänger",
    keywords: ["être", "sein", "hilfsverb", "unregelmäßig", "konjugation"],
    explanation: {
      title: "Das Verb être (sein)",
      introduction: "Être ist das wichtigste Verb im Französischen. Es wird als Vollverb und als Hilfsverb verwendet und ist komplett unregelmäßig.",
      content: [
        {
          title: "Konjugation von être im Präsens",
          description: "Die Formen von être müssen auswendig gelernt werden.",
          items: [
            { label: "je", value: "suis", explanation: "ich bin" },
            { label: "tu", value: "es", explanation: "du bist" },
            { label: "il/elle/on", value: "est", explanation: "er/sie/es ist" },
            { label: "nous", value: "sommes", explanation: "wir sind" },
            { label: "vous", value: "êtes", explanation: "ihr seid/Sie sind" },
            { label: "ils/elles", value: "sont", explanation: "sie sind" }
          ],
          examples: "Konjugation: je suis, tu es, il est, nous sommes, vous êtes, ils sont",
          detailedExamples: [
            {
              french: "Je suis étudiant",
              german: "Ich bin Student",
              explanation: "être wird für Berufe verwendet"
            },
            {
              french: "Tu es français?",
              german: "Bist du Franzose?",
              explanation: "être wird für Nationalitäten verwendet"
            },
            {
              french: "Il est dans le jardin",
              german: "Er ist im Garten",
              explanation: "être wird für Ortsangaben verwendet"
            }
          ],
          rules: [
            "être ist komplett unregelmäßig",
            "Die Formen müssen auswendig gelernt werden",
            "être wird oft in Verbindung mit Adjektiven verwendet"
          ]
        },
        {
          title: "Verwendung von être",
          description: "être hat verschiedene wichtige Funktionen.",
          items: [
            { label: "Identität:", value: "Je suis Paul", explanation: "Name/Person angeben" },
            { label: "Beruf:", value: "Il est médecin", explanation: "Berufsbezeichnung" },
            { label: "Nationalität:", value: "Elle est allemande", explanation: "Herkunft angeben" },
            { label: "Eigenschaft:", value: "Tu es intelligent", explanation: "Adjektive" },
            { label: "Ort:", value: "Nous sommes ici", explanation: "Ortsangabe" },
            { label: "Zeit:", value: "Il est 8 heures", explanation: "Uhrzeiten" }
          ],
          examples: "Verwendungen: c'est mon ami, elle est professeure, vous êtes sympas",
          rules: [
            "Bei Berufen oft ohne Artikel: il est professeur",
            "être wird für Uhrzeiten verwendet: il est midi",
            "être ist Hilfsverb für viele Verben im Passé composé"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wähle die richtige Form von 'être':",
        sentence: "Je ___ content.",
        options: ["suis", "es", "sommes"],
        correct: 0,
        explanation: "je suis ist die richtige Form von 'être' für 'ich bin'."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Tu ___ française?", answer: "es" },
          { sentence: "Nous ___ en vacances.", answer: "sommes" },
          { sentence: "Ils ___ très gentils.", answer: "sont" }
        ]
      },
      dragDrop: {
        articles: ["suis", "es", "est", "sommes", "êtes", "sont"],
        words: [
          { word: "je", correct: "suis" },
          { word: "vous", correct: "êtes" },
          { word: "elles", correct: "sont" }
        ]
      },
      matching: {
        articles: ["suis", "est", "sommes"],
        words: [
          { word: "je", translation: "ich bin", correct: "suis" },
          { word: "il", translation: "er ist", correct: "est" },
          { word: "nous", translation: "wir sind", correct: "sommes" }
        ]
      }
    }
  },
  {
    id: "verbs-avoir",
    title: "Das Verb avoir (haben)",
    subtitle: "Das zweite wichtige Hilfsverb",
    description: "Konjugation und Verwendung von avoir (haben)",
    icon: "fas fa-hand-holding",
    iconColor: "text-orange-500",
    bgColor: "bg-topic-orange",
    level: "anfänger",
    keywords: ["avoir", "haben", "hilfsverb", "unregelmäßig", "besitz"],
    explanation: {
      title: "Das Verb avoir (haben)",
      introduction: "Avoir ist das zweite wichtige unregelmäßige Verb im Französischen. Es drückt Besitz aus und dient als Hilfsverb.",
      content: [
        {
          title: "Konjugation von avoir im Präsens",
          description: "Auch avoir ist unregelmäßig und muss auswendig gelernt werden.",
          items: [
            { label: "j'", value: "ai", explanation: "ich habe" },
            { label: "tu", value: "as", explanation: "du hast" },
            { label: "il/elle/on", value: "a", explanation: "er/sie/es hat" },
            { label: "nous", value: "avons", explanation: "wir haben" },
            { label: "vous", value: "avez", explanation: "ihr habt/Sie haben" },
            { label: "ils/elles", value: "ont", explanation: "sie haben" }
          ],
          examples: "Konjugation: j'ai, tu as, il a, nous avons, vous avez, ils ont",
          detailedExamples: [
            {
              french: "J'ai un chien",
              german: "Ich habe einen Hund",
              explanation: "avoir für Besitz"
            },
            {
              french: "Tu as 18 ans",
              german: "Du bist 18 Jahre alt",
              explanation: "avoir für Altersangaben"
            },
            {
              french: "Nous avons faim",
              german: "Wir haben Hunger",
              explanation: "avoir in festen Ausdrücken"
            }
          ],
          rules: [
            "j' wird vor ai verwendet (nicht je)",
            "avoir ist komplett unregelmäßig",
            "avoir wird für Altersangaben verwendet"
          ]
        },
        {
          title: "Verwendung von avoir",
          description: "avoir hat verschiedene wichtige Funktionen.",
          items: [
            { label: "Besitz:", value: "J'ai une voiture", explanation: "etwas besitzen" },
            { label: "Alter:", value: "Il a 25 ans", explanation: "Altersangabe" },
            { label: "Körperliche Empfindungen:", value: "J'ai faim", explanation: "Hunger, Durst, etc." },
            { label: "Aussehen:", value: "Elle a les yeux bleus", explanation: "Beschreibung" },
            { label: "Krankheiten:", value: "Tu as mal à la tête", explanation: "Schmerzen" }
          ],
          examples: "Ausdrücke: avoir chaud, avoir froid, avoir peur, avoir raison",
          rules: [
            "avoir wird für viele feste Ausdrücke verwendet",
            "Bei Körperteilen: avoir mal à + Körperteil",
            "avoir ist Hilfsverb für die meisten Verben im Passé composé"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wähle die richtige Form von 'avoir':",
        sentence: "Vous ___ une belle maison.",
        options: ["avez", "avons", "ont"],
        correct: 0,
        explanation: "vous avez ist die richtige Form für 'ihr habt/Sie haben'."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Tu ___ un frère?", answer: "as" },
          { sentence: "Elle ___ 15 ans.", answer: "a" },
          { sentence: "Nous ___ de la chance.", answer: "avons" }
        ]
      },
      dragDrop: {
        articles: ["ai", "as", "a", "avons", "avez", "ont"],
        words: [
          { word: "j'", correct: "ai" },
          { word: "tu", correct: "as" },
          { word: "ils", correct: "ont" }
        ]
      },
      matching: {
        articles: ["as", "avons", "ont"],
        words: [
          { word: "tu", translation: "du hast", correct: "as" },
          { word: "nous", translation: "wir haben", correct: "avons" },
          { word: "ils", translation: "sie haben", correct: "ont" }
        ]
      }
    }
  },
  {
    id: "negation",
    title: "Verneinung",
    subtitle: "ne...pas, ne...plus, ne...jamais",
    description: "Die Verneinung mit ne...pas und anderen Formen",
    icon: "fas fa-times",
    iconColor: "text-red-500",
    bgColor: "bg-topic-red",
    level: "anfänger",
    keywords: ["verneinung", "ne", "pas", "negation", "nicht"],
    explanation: {
      title: "Die Verneinung im Französischen",
      introduction: "Im Französischen wird die Verneinung mit zwei Wörtern gebildet: ne + Verneinungswort. Die häufigste Form ist ne...pas.",
      content: [
        {
          title: "Grundregel: ne...pas",
          description: "Die Standardverneinung im Französischen.",
          items: [
            { label: "Struktur:", value: "ne + Verb + pas", explanation: "ne steht vor, pas nach dem Verb" },
            { label: "Vor Vokal:", value: "n' + Verb + pas", explanation: "ne wird zu n' verkürzt" }
          ],
          examples: "Beispiele: je ne parle pas, il n'est pas là",
          detailedExamples: [
            {
              french: "Je ne comprends pas",
              german: "Ich verstehe nicht",
              explanation: "Standardverneinung mit ne...pas"
            },
            {
              french: "Il n'habite pas ici",
              german: "Er wohnt nicht hier",
              explanation: "Vor Vokal wird ne zu n'"
            }
          ],
          rules: [
            "ne steht immer vor dem konjugierten Verb",
            "pas steht nach dem konjugierten Verb",
            "Bei zusammengesetzten Zeiten umschließt ne...pas das Hilfsverb"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Verneine den Satz richtig:",
        sentence: "Je ___ parle ___ français.",
        options: ["ne...pas", "pas...ne", "ne...plus"],
        correct: 0,
        explanation: "ne...pas ist die Standardverneinung."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il ___ aime ___ le chocolat.", answer: "ne...pas" },
          { sentence: "Nous ___ sommes ___ contents.", answer: "ne...pas" },
          { sentence: "Tu ___ as ___ d'argent.", answer: "n'...pas" }
        ]
      },
      dragDrop: {
        articles: ["ne", "n'", "pas"],
        words: [
          { word: "Je ___ mange ___", correct: "ne...pas" },
          { word: "Il ___ écoute ___", correct: "n'...pas" },
          { word: "Nous ___ dansons ___", correct: "ne...pas" }
        ]
      },
      matching: {
        articles: ["ne mange pas", "n'est pas", "ne parlent pas"],
        words: [
          { word: "il", translation: "er isst nicht", correct: "ne mange pas" },
          { word: "elle", translation: "sie ist nicht", correct: "n'est pas" },
          { word: "ils", translation: "sie sprechen nicht", correct: "ne parlent pas" }
        ]
      }
    }
  },
  {
    id: "questions",
    title: "Fragen bilden",
    subtitle: "Est-ce que, Inversion und W-Fragen",
    description: "Verschiedene Arten, Fragen im Französischen zu stellen",
    icon: "fas fa-question",
    iconColor: "text-indigo-500",
    bgColor: "bg-topic-indigo",
    level: "anfänger",
    keywords: ["fragen", "est-ce que", "inversion", "où", "comment", "pourquoi"],
    explanation: {
      title: "Fragen im Französischen",
      introduction: "Es gibt drei Hauptwege, Fragen zu stellen: mit Est-ce que, durch Inversion oder mit steigender Intonation.",
      content: [
        {
          title: "Fragen mit Est-ce que",
          description: "Die einfachste und häufigste Art, Fragen zu stellen.",
          items: [
            { label: "Struktur:", value: "Est-ce que + Aussagesatz?", explanation: "Einfach vor den Aussagesatz setzen" },
            { label: "Beispiel:", value: "Est-ce que tu parles français?", explanation: "Sprichst du Französisch?" }
          ],
          examples: "Weitere Beispiele: Est-ce que vous habitez ici? Est-ce qu'il vient?",
          rules: [
            "Est-ce que wird vor den unveränderten Aussagesatz gesetzt",
            "Vor Vokal wird que zu qu' verkürzt",
            "Dies ist die einfachste Frageform"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Bilde eine Frage mit 'Est-ce que':",
        sentence: "___ tu aimes le sport?",
        options: ["Est-ce que", "Qu'est-ce que", "Où est-ce que"],
        correct: 0,
        explanation: "Est-ce que wird für Ja/Nein-Fragen verwendet."
      },
      fillInBlanks: {
        questions: [
          { sentence: "___ vous habitez Paris?", answer: "Est-ce que" },
          { sentence: "Où ___-tu?", answer: "habites" },
          { sentence: "___ elle vient ce soir?", answer: "Est-ce que" }
        ]
      },
      dragDrop: {
        articles: ["Est-ce que", "Parles-tu", "Où", "Comment"],
        words: [
          { word: "tu viens? (kommst du?)", correct: "Est-ce que" },
          { word: "français? (sprichst du französisch?)", correct: "Parles-tu" },
          { word: "habites-tu? (wo wohnst du?)", correct: "Où" }
        ]
      },
      matching: {
        articles: ["Vient-elle?", "Est-ce qu'il mange?", "Où allez-vous?"],
        words: [
          { word: "Kommt sie?", translation: "", correct: "Vient-elle?" },
          { word: "Isst er?", translation: "", correct: "Est-ce qu'il mange?" },
          { word: "Wohin geht ihr?", translation: "", correct: "Où allez-vous?" }
        ]
      }
    }
  },
  {
    id: "possessive",
    title: "Possessivbegleiter",
    subtitle: "mon, ma, mes, ton, ta, tes, son, sa, ses...",
    description: "Besitzanzeigende Begleiter im Französischen",
    icon: "fas fa-heart",
    iconColor: "text-pink-500",
    bgColor: "bg-topic-pink",
    level: "anfänger",
    keywords: ["possessiv", "mon", "ma", "mes", "besitz", "mein", "dein"],
    explanation: {
      title: "Possessivbegleiter im Französischen",
      introduction: "Possessivbegleiter zeigen an, wem etwas gehört. Sie richten sich nach dem Besitzer und nach dem besessenen Objekt.",
      content: [
        {
          title: "1. Person Singular (mein/meine)",
          description: "Die Possessivbegleiter für 'ich'.",
          items: [
            { label: "männlich:", value: "mon", explanation: "mon père, mon livre" },
            { label: "weiblich:", value: "ma", explanation: "ma mère, ma voiture" },
            { label: "Plural:", value: "mes", explanation: "mes parents, mes livres" }
          ],
          examples: "Beispiele: mon chien, ma maison, mes amis",
          rules: [
            "Vor weiblichen Wörtern mit Vokal steht 'mon' statt 'ma'",
            "Beispiel: mon école (nicht ma école)",
            "Der Possessivbegleiter richtet sich nach dem besessenen Objekt"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wähle den richtigen Possessivbegleiter:",
        sentence: "C'est ___ voiture.",
        options: ["mon", "ma", "mes"],
        correct: 1,
        explanation: "ma voiture ist korrekt, weil 'voiture' weiblich ist."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Où est ___ sac?", answer: "ton" },
          { sentence: "___ amis sont sympas.", answer: "Mes" },
          { sentence: "J'aime ___ maison.", answer: "ta" }
        ]
      },
      dragDrop: {
        articles: ["mon", "ma", "mes", "ton", "ta", "tes"],
        words: [
          { word: "mère (f.)", correct: "ma" },
          { word: "frère (m.)", correct: "ton" },
          { word: "enfants (pl.)", correct: "mes" }
        ]
      },
      matching: {
        articles: ["notre", "votre", "leur"],
        words: [
          { word: "maison", translation: "unser Haus", correct: "notre" },
          { word: "chien", translation: "euer Hund", correct: "votre" },
          { word: "jardin", translation: "ihr Garten", correct: "leur" }
        ]
      }
    }
  },
  {
    id: "adjectives",
    title: "Adjektive",
    subtitle: "Angleichung männlich/weiblich, Plural",
    description: "Adjektive und ihre Anpassung an Geschlecht und Zahl",
    icon: "fas fa-palette",
    iconColor: "text-teal-500",
    bgColor: "bg-topic-teal",
    level: "anfänger",
    keywords: ["adjektive", "angleichung", "männlich", "weiblich", "plural", "accord"],
    explanation: {
      title: "Adjektive im Französischen",
      introduction: "Adjektive passen sich an das Geschlecht und die Zahl des Substantivs an, das sie beschreiben.",
      content: [
        {
          title: "Grundregeln der Angleichung",
          description: "So werden Adjektive angepasst.",
          items: [
            { label: "männlich Singular:", value: "petit", explanation: "Grundform" },
            { label: "weiblich Singular:", value: "petite", explanation: "meist +e" },
            { label: "männlich Plural:", value: "petits", explanation: "meist +s" },
            { label: "weiblich Plural:", value: "petites", explanation: "meist +es" }
          ],
          examples: "Beispiele: un petit garçon, une petite fille, des petits garçons, des petites filles",
          rules: [
            "Die meisten Adjektive bekommen +e für weiblich",
            "Die meisten Adjektive bekommen +s für Plural",
            "Manche Adjektive sind unveränderlich"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Passe das Adjektiv an:",
        sentence: "Ma sœur est très ___.",
        options: ["grand", "grande", "grands"],
        correct: 1,
        explanation: "grande ist korrekt, weil 'sœur' weiblich ist."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Les filles sont ___. (intelligent)", answer: "intelligentes" },
          { sentence: "Il est très ___. (gentil)", answer: "gentil" },
          { sentence: "Ma voiture est ___. (rouge)", answer: "rouge" }
        ]
      },
      dragDrop: {
        articles: ["petit", "petite", "petits", "petites"],
        words: [
          { word: "garçon", correct: "petit" },
          { word: "filles", correct: "petites" },
          { word: "maison", correct: "petite" }
        ]
      },
      matching: {
        articles: ["belle", "nouveaux", "vieilles"],
        words: [
          { word: "femme", translation: "schöne Frau", correct: "belle" },
          { word: "livres", translation: "neue Bücher", correct: "nouveaux" },
          { word: "voitures", translation: "alte Autos", correct: "vieilles" }
        ]
      }
    }
  },
  {
    id: "time-telling",
    title: "Uhrzeiten",
    subtitle: "Die Uhrzeit auf Französisch ausdrücken",
    description: "Uhrzeiten mit il est, formelle und informelle Zeit",
    icon: "fas fa-clock",
    iconColor: "text-yellow-500",
    bgColor: "bg-topic-yellow",
    level: "anfänger",
    keywords: ["uhrzeit", "il est", "heure", "quart", "demie", "moins", "zeit"],
    explanation: {
      title: "Uhrzeiten im Französischen",
      introduction: "Die Uhrzeit wird mit 'il est' eingeleitet. Es gibt formelle (24-Stunden) und informelle (12-Stunden) Zeitangaben.",
      content: [
        {
          title: "Grundstrukturen für Uhrzeiten",
          description: "Die wichtigsten Zeitangaben und ihre Bildung.",
          items: [
            { label: "volle Stunden:", value: "Il est... heure(s)", explanation: "Il est une heure, Il est trois heures" },
            { label: "Viertel nach:", value: "et quart", explanation: "Il est deux heures et quart (14:15)" },
            { label: "halb:", value: "et demie", explanation: "Il est trois heures et demie (15:30)" },
            { label: "Viertel vor:", value: "moins le quart", explanation: "Il est quatre heures moins le quart (15:45)" },
            { label: "Minuten nach:", value: "et + Minuten", explanation: "Il est deux heures et dix (14:10)" },
            { label: "Minuten vor:", value: "moins + Minuten", explanation: "Il est trois heures moins cinq (14:55)" }
          ],
          examples: "Beispiele: Il est midi, Il est minuit, Il est huit heures du matin",
          detailedExamples: [
            {
              french: "Il est quatorze heures trente",
              german: "Es ist 14:30",
              explanation: "Formelle Zeit (24-Stunden-Format)"
            },
            {
              french: "Il est deux heures et demie de l'après-midi",
              german: "Es ist halb drei nachmittags",
              explanation: "Informelle Zeit mit Tageszeit"
            },
            {
              french: "Il est neuf heures moins le quart",
              german: "Es ist Viertel vor neun",
              explanation: "Informelle Zeit mit 'moins le quart'"
            }
          ],
          rules: [
            "Bei 1 Uhr: 'une heure' (Singular), sonst 'heures' (Plural)",
            "Bei formeller Zeit: keine 'et quart', 'et demie', sondern Minuten",
            "Tageszeiten: du matin, de l'après-midi, du soir"
          ]
        },
        {
          title: "Tageszeiten und besondere Uhrzeiten",
          description: "Wie man verschiedene Tageszeiten ausdrückt.",
          items: [
            { label: "Mittag:", value: "midi", explanation: "Il est midi (12:00)" },
            { label: "Mitternacht:", value: "minuit", explanation: "Il est minuit (00:00)" },
            { label: "morgens:", value: "du matin", explanation: "Il est huit heures du matin" },
            { label: "nachmittags:", value: "de l'après-midi", explanation: "Il est deux heures de l'après-midi" },
            { label: "abends:", value: "du soir", explanation: "Il est huit heures du soir" }
          ],
          examples: "Tageszeiten: Il est sept heures du matin, Il est minuit et quart",
          rules: [
            "midi und minuit sind männlich (le midi, le minuit)",
            "Nach midi und minuit keine 'heures'",
            "Tageszeiten werden nur bei 12-Stunden-Format verwendet"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie sagt man '14:30'?",
        sentence: "Il est...",
        options: ["deux heures et demie", "quatorze heures trente", "deux heures trente"],
        correct: 1,
        explanation: "quatorze heures trente ist die formelle Zeit für 14:30."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il est midi ___ quart. (12:15)", answer: "et" },
          { sentence: "Il est trois heures ___ dix. (2:50)", answer: "moins" },
          { sentence: "Il est ___ heures. (8:00)", answer: "huit" }
        ]
      },
      dragDrop: {
        articles: ["et quart", "et demie", "moins le quart", "pile"],
        words: [
          { word: "15:15", correct: "et quart" },
          { word: "12:30", correct: "et demie" },
          { word: "16:45", correct: "moins le quart" }
        ]
      },
      matching: {
        articles: ["neuf heures", "midi", "minuit"],
        words: [
          { word: "9:00", translation: "", correct: "neuf heures" },
          { word: "12:00", translation: "", correct: "midi" },
          { word: "0:00", translation: "", correct: "minuit" }
        ]
      }
    }
  },
  {
    id: "prepositions-place",
    title: "Ortsangaben",
    subtitle: "Präpositionen des Ortes: à, en, chez, dans, sur...",
    description: "Präpositionen für Ortsangaben und Richtungen",
    icon: "fas fa-map-marker-alt",
    iconColor: "text-purple-500",
    bgColor: "bg-topic-purple",
    level: "mittelstufe",
    keywords: ["präpositionen", "ort", "à", "en", "chez", "dans", "sur", "sous"],
    explanation: {
      title: "Ortsangaben im Französischen",
      introduction: "Präpositionen des Ortes geben an, wo sich etwas befindet oder wohin sich etwas bewegt. Jede Präposition hat spezielle Verwendungsregeln.",
      content: [
        {
          title: "Grundlegende Ortspräpositionen",
          description: "Die wichtigsten Präpositionen für Ortsangaben.",
          items: [
            { label: "à:", value: "in, nach, zu", explanation: "à Paris, à l'école, à la maison" },
            { label: "en:", value: "in, nach (Länder)", explanation: "en France, en Allemagne, en Italie" },
            { label: "chez:", value: "bei, zu (Personen)", explanation: "chez Pierre, chez le médecin" },
            { label: "dans:", value: "in (Räume/Container)", explanation: "dans la cuisine, dans le sac" },
            { label: "sur:", value: "auf", explanation: "sur la table, sur le toit" },
            { label: "sous:", value: "unter", explanation: "sous la table, sous le lit" }
          ],
          examples: "Beispiele: Je vais à Berlin, Elle habite en France, Il est chez Marie",
          detailedExamples: [
            {
              french: "Je travaille à la banque",
              german: "Ich arbeite in der Bank",
              explanation: "'à' wird bei Institutionen und Arbeitsplätzen verwendet"
            },
            {
              french: "Nous habitons en Suisse",
              german: "Wir wohnen in der Schweiz",
              explanation: "'en' wird bei weiblichen Ländern ohne Artikel verwendet"
            },
            {
              french: "Le chat est sous la voiture",
              german: "Die Katze ist unter dem Auto",
              explanation: "'sous' drückt die Position 'unter' aus"
            }
          ],
          rules: [
            "'à' wird für Städte und viele Orte verwendet",
            "'en' für weibliche Länder und Verkehrsmittel",
            "'chez' nur für Personen oder Geschäfte mit Personennamen"
          ]
        },
        {
          title: "Besondere Regeln für Länder und Städte",
          description: "Spezifische Präpositionen je nach geografischem Typ.",
          items: [
            { label: "Städte:", value: "à", explanation: "à Paris, à Londres, à New York" },
            { label: "weibliche Länder:", value: "en", explanation: "en France, en Allemagne" },
            { label: "männliche Länder:", value: "au", explanation: "au Japon, au Brésil" },
            { label: "Plural-Länder:", value: "aux", explanation: "aux États-Unis, aux Pays-Bas" },
            { label: "Inseln:", value: "à", explanation: "à Madagascar, à Chypre" }
          ],
          examples: "Länder: Je vais au Canada, Elle vient des États-Unis",
          rules: [
            "Länder auf -e sind meist weiblich (Ausnahme: le Mexique)",
            "Bei Ländern mit Artikel: au (m.), aux (pl.)",
            "Herkunft: de/d' (Städte), de/du/des (Länder)"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wähle die richtige Präposition:",
        sentence: "Je vais ___ France.",
        options: ["à", "en", "chez"],
        correct: 1,
        explanation: "en France ist korrekt für weibliche Länder."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il habite ___ Berlin.", answer: "à" },
          { sentence: "Nous sommes ___ Marie.", answer: "chez" },
          { sentence: "Le livre est ___ la table.", answer: "sur" }
        ]
      },
      dragDrop: {
        articles: ["à", "en", "chez", "dans"],
        words: [
          { word: "Paris", correct: "à" },
          { word: "Allemagne", correct: "en" },
          { word: "mes parents", correct: "chez" }
        ]
      },
      matching: {
        articles: ["au", "aux", "du"],
        words: [
          { word: "cinéma", translation: "ins Kino", correct: "au" },
          { word: "États-Unis", translation: "in die USA", correct: "aux" },
          { word: "Canada", translation: "aus Kanada", correct: "du" }
        ]
      }
    }
  },
  {
    id: "futur-compose",
    title: "Futur Composé",
    subtitle: "Die nahe Zukunft mit aller + Infinitiv",
    description: "Zukunft ausdrücken mit dem Futur Composé",
    icon: "fas fa-fast-forward",
    iconColor: "text-green-500",
    bgColor: "bg-topic-green",
    level: "mittelstufe",
    keywords: ["futur", "aller", "zukunft", "infinitiv", "composé"],
    explanation: {
      title: "Das Futur Composé (nahe Zukunft)",
      introduction: "Das Futur Composé drückt Handlungen aus, die in naher Zukunft stattfinden werden. Es wird mit dem Verb 'aller' + Infinitiv gebildet.",
      content: [
        {
          title: "Bildung des Futur Composé",
          description: "Die Bildung erfolgt mit aller (konjugiert) + Infinitiv des Hauptverbs.",
          items: [
            { label: "je", value: "vais + Infinitiv", explanation: "Je vais manger" },
            { label: "tu", value: "vas + Infinitiv", explanation: "Tu vas partir" },
            { label: "il/elle/on", value: "va + Infinitiv", explanation: "Il va venir" },
            { label: "nous", value: "allons + Infinitiv", explanation: "Nous allons regarder" },
            { label: "vous", value: "allez + Infinitiv", explanation: "Vous allez étudier" },
            { label: "ils/elles", value: "vont + Infinitiv", explanation: "Ils vont jouer" }
          ],
          examples: "Beispiele: Je vais acheter du pain, Tu vas voir tes amis",
          detailedExamples: [
            {
              french: "Nous allons visiter Paris demain",
              german: "Wir werden morgen Paris besuchen",
              explanation: "Geplante Handlung in naher Zukunft"
            },
            {
              french: "Il va pleuvoir ce soir",
              german: "Es wird heute Abend regnen",
              explanation: "Vorhersage für die nahe Zukunft"
            },
            {
              french: "Qu'est-ce que tu vas faire?",
              german: "Was wirst du machen?",
              explanation: "Frage nach zukünftigen Plänen"
            }
          ],
          rules: [
            "aller wird normal konjugiert, das Hauptverb bleibt im Infinitiv",
            "Zeitangaben der nahen Zukunft: demain, ce soir, bientôt",
            "Verneinung umschließt nur das konjugierte Verb aller"
          ]
        },
        {
          title: "Verwendung des Futur Composé",
          description: "Wann und wie das Futur Composé verwendet wird.",
          items: [
            { label: "Nahe Zukunft:", value: "bevorstehende Handlungen", explanation: "Je vais partir dans 5 minutes" },
            { label: "Pläne:", value: "geplante Aktivitäten", explanation: "Nous allons faire du sport" },
            { label: "Vorhersagen:", value: "wahrscheinliche Ereignisse", explanation: "Il va faire beau" },
            { label: "Absichten:", value: "beabsichtigte Handlungen", explanation: "Je vais apprendre le français" }
          ],
          examples: "Verwendung: Je vais téléphoner à ma mère, Il va neiger",
          rules: [
            "Meist für Ereignisse innerhalb der nächsten 24-48 Stunden",
            "Drückt Sicherheit oder hohe Wahrscheinlichkeit aus",
            "Alternativer Begriff: futur proche (nahe Zukunft)"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Bilde das Futur Composé:",
        sentence: "Nous ___ regarder un film.",
        options: ["allons", "allez", "vont"],
        correct: 0,
        explanation: "nous allons ist die richtige Form für 'wir werden'."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Je ___ acheter du pain.", answer: "vais" },
          { sentence: "Tu ___ voir tes amis?", answer: "vas" },
          { sentence: "Il ___ pleuvoir.", answer: "va" }
        ]
      },
      dragDrop: {
        articles: ["vais", "vas", "va", "allons", "allez", "vont"],
        words: [
          { word: "je _____ manger", correct: "vais" },
          { word: "vous _____ partir", correct: "allez" },
          { word: "elles _____ venir", correct: "vont" }
        ]
      },
      matching: {
        articles: ["vais faire", "allons voir", "va partir"],
        words: [
          { word: "je", translation: "ich werde machen", correct: "vais faire" },
          { word: "nous", translation: "wir werden sehen", correct: "allons voir" },
          { word: "il", translation: "er wird gehen", correct: "va partir" }
        ]
      }
    }
  },
  {
    id: "passe-compose",
    title: "Passé Composé",
    subtitle: "Die zusammengesetzte Vergangenheit",
    description: "Vergangenheit mit avoir und être bilden",
    icon: "fas fa-history",
    iconColor: "text-orange-600",
    bgColor: "bg-orange-100",
    level: "mittelstufe",
    keywords: ["passé composé", "vergangenheit", "avoir", "être", "participe passé"],
    explanation: {
      title: "Das Passé Composé",
      introduction: "Das Passé Composé ist die wichtigste Vergangenheitsform im Französischen. Es wird mit avoir oder être + Partizip Perfekt gebildet.",
      content: [
        {
          title: "Bildung mit avoir",
          description: "Die meisten Verben bilden das Passé Composé mit avoir.",
          items: [
            { label: "Struktur:", value: "avoir + Partizip Perfekt", explanation: "J'ai mangé, Tu as parlé" },
            { label: "Partizip -er:", value: "-é", explanation: "parler → parlé, manger → mangé" },
            { label: "Partizip -ir:", value: "-i", explanation: "finir → fini, choisir → choisi" },
            { label: "Partizip -re:", value: "-u", explanation: "vendre → vendu, attendre → attendu" }
          ],
          examples: "Beispiele: J'ai travaillé hier, Il a fini ses devoirs",
          detailedExamples: [
            {
              french: "Nous avons visité le musée",
              german: "Wir haben das Museum besucht",
              explanation: "Regelmäßiges Partizip: visiter → visité"
            },
            {
              french: "Elle a choisi cette robe",
              german: "Sie hat dieses Kleid gewählt",
              explanation: "Regelmäßiges Partizip: choisir → choisi"
            }
          ],
          rules: [
            "avoir wird normal konjugiert",
            "Das Partizip richtet sich nicht nach dem Subjekt",
            "Verneinung umschließt das Hilfsverb avoir"
          ]
        },
        {
          title: "Bildung mit être",
          description: "Bewegungsverben und reflexive Verben verwenden être.",
          items: [
            { label: "Bewegungsverben:", value: "aller, venir, partir...", explanation: "Je suis allé(e)" },
            { label: "Zustandsverben:", value: "naître, mourir, rester...", explanation: "Il est né" },
            { label: "Partizip-Angleichung:", value: "nach Subjekt", explanation: "Elle est partie, Ils sont venus" }
          ],
          examples: "être-Verben: Je suis arrivé(e), Tu es parti(e)",
          rules: [
            "Partizip passt sich an Subjekt an (Geschlecht/Zahl)",
            "16 Hauptverben verwenden être als Hilfsverb",
            "Merksatz: DR MRS VANDERTRAMP"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welches Hilfsverb ist richtig?",
        sentence: "Elle ___ partie hier.",
        options: ["a", "est", "sont"],
        correct: 1,
        explanation: "'partir' verwendet être als Hilfsverb."
      },
      fillInBlanks: {
        questions: [
          { sentence: "J'___ mangé une pomme.", answer: "ai" },
          { sentence: "Nous ___ allés au cinéma.", answer: "sommes" },
          { sentence: "Tu ___ fini tes devoirs?", answer: "as" }
        ]
      },
      dragDrop: {
        articles: ["ai parlé", "est venue", "avons fini", "sont partis"],
        words: [
          { word: "j'_____ français", correct: "ai parlé" },
          { word: "elle _____ ici", correct: "est venue" },
          { word: "nous _____ le travail", correct: "avons fini" }
        ]
      },
      matching: {
        articles: ["as mangé", "suis allé", "ont vu"],
        words: [
          { word: "tu", translation: "du hast gegessen", correct: "as mangé" },
          { word: "je", translation: "ich bin gegangen", correct: "suis allé" },
          { word: "ils", translation: "sie haben gesehen", correct: "ont vu" }
        ]
      }
    }
  },
  {
    id: "numbers-1-100",
    title: "Zahlen 1-100",
    subtitle: "Grundzahlen im Französischen",
    description: "Zahlen von eins bis hundert lernen",
    icon: "fas fa-calculator",
    iconColor: "text-blue-600",
    bgColor: "bg-blue-100",
    level: "anfänger",
    keywords: ["zahlen", "nombres", "un", "deux", "trois", "cent", "chiffres"],
    explanation: {
      title: "Französische Zahlen 1-100",
      introduction: "Die französischen Zahlen folgen einem logischen System, haben aber einige Besonderheiten, besonders bei den Zahlen 70-99.",
      content: [
        {
          title: "Grundzahlen 1-20",
          description: "Diese Zahlen müssen auswendig gelernt werden.",
          items: [
            { label: "1-10:", value: "un, deux, trois, quatre, cinq, six, sept, huit, neuf, dix", explanation: "Grundzahlen" },
            { label: "11-16:", value: "onze, douze, treize, quatorze, quinze, seize", explanation: "Unregelmäßige Formen" },
            { label: "17-19:", value: "dix-sept, dix-huit, dix-neuf", explanation: "zehn + Einer" },
            { label: "20:", value: "vingt", explanation: "Grundlage für weitere Zehner" }
          ],
          examples: "Aussprache: un [œ̃], deux [dø], trois [tʁwa], quatre [katʁ]",
          detailedExamples: [
            {
              french: "J'ai quinze ans",
              german: "Ich bin fünfzehn Jahre alt",
              explanation: "Zahlen bei Altersangaben"
            },
            {
              french: "Il est trois heures",
              german: "Es ist drei Uhr",
              explanation: "Zahlen bei Uhrzeiten"
            }
          ],
          rules: [
            "un wird zu une vor weiblichen Substantiven",
            "Zahlen 1-16 sind komplett unregelmäßig",
            "17-19 werden zusammengesetzt: dix + Bindestrich + Einer"
          ]
        },
        {
          title: "Zehnerzahlen und Besonderheiten",
          description: "Das französische Zahlensystem hat Besonderheiten bei 70-99.",
          items: [
            { label: "Zehner 20-60:", value: "vingt, trente, quarante, cinquante, soixante", explanation: "Regelmäßige Zehner" },
            { label: "70:", value: "soixante-dix", explanation: "60 + 10 (nicht septante)" },
            { label: "80:", value: "quatre-vingts", explanation: "4 × 20 (nicht octante)" },
            { label: "90:", value: "quatre-vingt-dix", explanation: "4 × 20 + 10 (nicht nonante)" },
            { label: "100:", value: "cent", explanation: "Hundert" }
          ],
          examples: "Besonderheiten: 71 = soixante et onze, 81 = quatre-vingt-un",
          rules: [
            "Bei 21, 31, 41, 51, 61, 71: 'et' zwischen Zehnern und Einern",
            "quatre-vingts verliert das -s vor weiteren Zahlen",
            "90er werden mit quatre-vingt-dix- gebildet"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie sagt man '75'?",
        sentence: "",
        options: ["soixante-quinze", "septante-cinq", "soixante et quinze"],
        correct: 0,
        explanation: "75 = soixante-quinze (60 + 15)"
      },
      fillInBlanks: {
        questions: [
          { sentence: "J'ai _____ ans. (23)", answer: "vingt-trois" },
          { sentence: "Il coûte _____ euros. (87)", answer: "quatre-vingt-sept" },
          { sentence: "Nous sommes _____. (31)", answer: "trente et un" }
        ]
      },
      dragDrop: {
        articles: ["vingt", "trente", "quarante", "cinquante"],
        words: [
          { word: "20", correct: "vingt" },
          { word: "40", correct: "quarante" },
          { word: "50", correct: "cinquante" }
        ]
      },
      matching: {
        articles: ["soixante-dix", "quatre-vingts", "quatre-vingt-dix"],
        words: [
          { word: "70", translation: "", correct: "soixante-dix" },
          { word: "80", translation: "", correct: "quatre-vingts" },
          { word: "90", translation: "", correct: "quatre-vingt-dix" }
        ]
      }
    }
  },
  {
    id: "days-months",
    title: "Wochentage und Monate",
    subtitle: "Temporale Ausdrücke im Französischen",
    description: "Tage, Monate und Jahreszeiten benennen",
    icon: "fas fa-calendar",
    iconColor: "text-purple-600",
    bgColor: "bg-purple-100",
    level: "anfänger",
    keywords: ["wochentage", "monate", "jahreszeiten", "lundi", "janvier", "été"],
    explanation: {
      title: "Wochentage und Monate",
      introduction: "Zeitangaben sind essentiell für die tägliche Kommunikation. Im Französischen werden Wochentage und Monate klein geschrieben.",
      content: [
        {
          title: "Die sieben Wochentage",
          description: "Alle Wochentage sind männlich und werden mit 'le' verwendet.",
          items: [
            { label: "Montag:", value: "lundi", explanation: "le lundi (montags)" },
            { label: "Dienstag:", value: "mardi", explanation: "le mardi (dienstags)" },
            { label: "Mittwoch:", value: "mercredi", explanation: "le mercredi (mittwochs)" },
            { label: "Donnerstag:", value: "jeudi", explanation: "le jeudi (donnerstags)" },
            { label: "Freitag:", value: "vendredi", explanation: "le vendredi (freitags)" },
            { label: "Samstag:", value: "samedi", explanation: "le samedi (samstags)" },
            { label: "Sonntag:", value: "dimanche", explanation: "le dimanche (sonntags)" }
          ],
          examples: "Heute ist Montag = C'est lundi aujourd'hui",
          detailedExamples: [
            {
              french: "Je travaille du lundi au vendredi",
              german: "Ich arbeite von Montag bis Freitag",
              explanation: "Zeitraum mit 'du...au'"
            },
            {
              french: "Le dimanche, je me repose",
              german: "Sonntags ruhe ich mich aus",
              explanation: "Gewohnheit mit 'le + Wochentag'"
            }
          ],
          rules: [
            "Alle Wochentage sind männlich",
            "Klein geschrieben (außer am Satzanfang)",
            "'le + Wochentag' = jeden + Wochentag (Gewohnheit)"
          ]
        },
        {
          title: "Die zwölf Monate",
          description: "Monate werden ebenfalls klein geschrieben und sind alle männlich.",
          items: [
            { label: "Winter:", value: "janvier, février, décembre", explanation: "Wintermonate" },
            { label: "Frühling:", value: "mars, avril, mai", explanation: "Frühlingsmonate" },
            { label: "Sommer:", value: "juin, juillet, août", explanation: "Sommermonate" },
            { label: "Herbst:", value: "septembre, octobre, novembre", explanation: "Herbstmonate" }
          ],
          examples: "Im Januar = en janvier, Am 15. Mai = le 15 mai",
          rules: [
            "Monate mit 'en': en janvier, en février",
            "Datum: le + Zahl + Monat",
            "Jahreszeiten: au printemps, en été, en automne, en hiver"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welcher Tag kommt nach mardi?",
        sentence: "",
        options: ["mercredi", "lundi", "jeudi"],
        correct: 0,
        explanation: "Nach mardi (Dienstag) kommt mercredi (Mittwoch)."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Mon anniversaire est en _____. (Juli)", answer: "juillet" },
          { sentence: "_____ est le premier jour de la semaine.", answer: "Lundi" },
          { sentence: "Noël est en _____.", answer: "décembre" }
        ]
      },
      dragDrop: {
        articles: ["lundi", "mardi", "mercredi", "jeudi"],
        words: [
          { word: "Montag", correct: "lundi" },
          { word: "Mittwoch", correct: "mercredi" },
          { word: "Donnerstag", correct: "jeudi" }
        ]
      },
      matching: {
        articles: ["janvier", "juillet", "décembre"],
        words: [
          { word: "Januar", translation: "", correct: "janvier" },
          { word: "Juli", translation: "", correct: "juillet" },
          { word: "Dezember", translation: "", correct: "décembre" }
        ]
      }
    }
  },
  {
    id: "colors",
    title: "Farben",
    subtitle: "Farbadjektive und ihre Verwendung",
    description: "Farben benennen und als Adjektive verwenden",
    icon: "fas fa-palette",
    iconColor: "text-pink-600",
    bgColor: "bg-pink-100",
    level: "anfänger",
    keywords: ["farben", "couleurs", "rouge", "bleu", "vert", "adjektive"],
    explanation: {
      title: "Farben im Französischen",
      introduction: "Farben sind Adjektive und müssen sich an das Geschlecht und die Zahl des beschriebenen Substantivs anpassen.",
      content: [
        {
          title: "Grundfarben",
          description: "Die wichtigsten Farben und ihre Anpassung.",
          items: [
            { label: "rot:", value: "rouge", explanation: "un pull rouge, une voiture rouge" },
            { label: "blau:", value: "bleu(e)", explanation: "un ciel bleu, une mer bleue" },
            { label: "grün:", value: "vert(e)", explanation: "un arbre vert, une pomme verte" },
            { label: "gelb:", value: "jaune", explanation: "un soleil jaune, une fleur jaune" },
            { label: "schwarz:", value: "noir(e)", explanation: "un chat noir, une robe noire" },
            { label: "weiß:", value: "blanc(he)", explanation: "un mur blanc, une chemise blanche" }
          ],
          examples: "Beispiele: J'ai une voiture rouge, Il porte un pantalon noir",
          detailedExamples: [
            {
              french: "Elle a les yeux bleus",
              german: "Sie hat blaue Augen",
              explanation: "Farbadjektiv nach dem Substantiv"
            },
            {
              french: "Ma robe préférée est noire",
              german: "Mein Lieblingskleid ist schwarz",
              explanation: "Farbe als Prädikat"
            }
          ],
          rules: [
            "Die meisten Farben stehen nach dem Substantiv",
            "Farben passen sich an Geschlecht und Zahl an",
            "Einige Farben sind unveränderlich (orange, marron)"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welche Farbe passt?",
        sentence: "Ma voiture est ___.",
        options: ["rouge", "rouges", "blanc"],
        correct: 0,
        explanation: "rouge passt sich nicht an das Geschlecht an."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Le ciel est ___.", answer: "bleu" },
          { sentence: "J'ai une robe ___.", answer: "verte" },
          { sentence: "Les fleurs sont ___.", answer: "jaunes" }
        ]
      },
      dragDrop: {
        articles: ["rouge", "bleue", "verts", "noires"],
        words: [
          { word: "voiture (f.)", correct: "rouge" },
          { word: "mer (f.)", correct: "bleue" },
          { word: "arbres (m.pl.)", correct: "verts" }
        ]
      },
      matching: {
        articles: ["blanc", "noire", "jaunes"],
        words: [
          { word: "mur", translation: "weiße Wand", correct: "blanc" },
          { word: "nuit", translation: "schwarze Nacht", correct: "noire" },
          { word: "fleurs", translation: "gelbe Blumen", correct: "jaunes" }
        ]
      }
    }
  },
  {
    id: "family",
    title: "Familie",
    subtitle: "Familienmitglieder benennen",
    description: "Verwandtschaftsbezeichnungen im Französischen",
    icon: "fas fa-users",
    iconColor: "text-green-600",
    bgColor: "bg-green-100",
    level: "anfänger",
    keywords: ["familie", "famille", "père", "mère", "frère", "sœur", "verwandtschaft"],
    explanation: {
      title: "Die Familie",
      introduction: "Familienmitglieder zu benennen ist grundlegend für persönliche Gespräche. Viele Verwandtschaftsbezeichnungen haben männliche und weibliche Formen.",
      content: [
        {
          title: "Kernfamilie",
          description: "Die engsten Familienmitglieder.",
          items: [
            { label: "Vater:", value: "le père", explanation: "Mon père s'appelle..." },
            { label: "Mutter:", value: "la mère", explanation: "Ma mère travaille..." },
            { label: "Bruder:", value: "le frère", explanation: "J'ai un frère" },
            { label: "Schwester:", value: "la sœur", explanation: "Ma sœur est sympa" },
            { label: "Sohn:", value: "le fils", explanation: "C'est mon fils" },
            { label: "Tochter:", value: "la fille", explanation: "Voici ma fille" }
          ],
          examples: "Familie vorstellen: Voici ma famille, J'ai deux frères",
          detailedExamples: [
            {
              french: "Dans ma famille, nous sommes quatre",
              german: "In meiner Familie sind wir vier",
              explanation: "Familie beschreiben"
            },
            {
              french: "Mon petit frère a dix ans",
              german: "Mein kleiner Bruder ist zehn Jahre alt",
              explanation: "Familienmitglied mit Adjektiv"
            }
          ],
          rules: [
            "Possessivbegleiter vor Familienmitgliedern: mon père, ma mère",
            "'fille' bedeutet sowohl Mädchen als auch Tochter",
            "Bei mehreren Geschwistern: mes frères, mes sœurs"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie sagt man 'meine Schwester'?",
        sentence: "",
        options: ["ma sœur", "mon sœur", "mes sœur"],
        correct: 0,
        explanation: "ma sœur - sœur ist weiblich, daher 'ma'."
      },
      fillInBlanks: {
        questions: [
          { sentence: "___ père est médecin.", answer: "Mon" },
          { sentence: "J'ai deux ___.", answer: "frères" },
          { sentence: "___ famille est grande.", answer: "Ma" }
        ]
      },
      dragDrop: {
        articles: ["père", "mère", "frère", "sœur"],
        words: [
          { word: "Vater", correct: "père" },
          { word: "Schwester", correct: "sœur" },
          { word: "Mutter", correct: "mère" }
        ]
      },
      matching: {
        articles: ["mon père", "ma mère", "mes parents"],
        words: [
          { word: "mein Vater", translation: "", correct: "mon père" },
          { word: "meine Mutter", translation: "", correct: "ma mère" },
          { word: "meine Eltern", translation: "", correct: "mes parents" }
        ]
      }
    }
  },
  {
    id: "body-parts",
    title: "Körperteile",
    subtitle: "Den menschlichen Körper beschreiben",
    description: "Körperteile benennen und beschreiben",
    icon: "fas fa-male",
    iconColor: "text-orange-600",
    bgColor: "bg-orange-100",
    level: "anfänger",
    keywords: ["körper", "corps", "tête", "main", "pied", "œil", "körperteile"],
    explanation: {
      title: "Körperteile im Französischen",
      introduction: "Körperteile zu kennen ist wichtig für Beschreibungen, beim Arzt oder im Sport. Viele haben unregelmäßige Pluralformen.",
      content: [
        {
          title: "Kopf und Gesicht",
          description: "Die wichtigsten Körperteile am Kopf.",
          items: [
            { label: "Kopf:", value: "la tête", explanation: "J'ai mal à la tête" },
            { label: "Auge/Augen:", value: "l'œil / les yeux", explanation: "Il a les yeux bleus" },
            { label: "Nase:", value: "le nez", explanation: "un grand nez" },
            { label: "Mund:", value: "la bouche", explanation: "ouvrir la bouche" },
            { label: "Ohr/Ohren:", value: "l'oreille / les oreilles", explanation: "mal aux oreilles" },
            { label: "Haar:", value: "les cheveux", explanation: "cheveux blonds" }
          ],
          examples: "Beschreibung: Elle a de beaux yeux, Il a les cheveux courts",
          detailedExamples: [
            {
              french: "J'ai mal aux yeux",
              german: "Mir tun die Augen weh",
              explanation: "avoir mal à + Körperteil"
            },
            {
              french: "Il a les cheveux noirs",
              german: "Er hat schwarze Haare",
              explanation: "Haarfarbe beschreiben"
            }
          ],
          rules: [
            "Bei Schmerzen: avoir mal à + Artikel + Körperteil",
            "œil → yeux (unregelmäßiger Plural)",
            "cheveux ist immer Plural"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie ist der Plural von 'œil'?",
        sentence: "",
        options: ["œils", "yeux", "œux"],
        correct: 1,
        explanation: "Der Plural von œil ist yeux (unregelmäßig)."
      },
      fillInBlanks: {
        questions: [
          { sentence: "J'ai mal à la ___.", answer: "tête" },
          { sentence: "Elle a de beaux ___.", answer: "yeux" },
          { sentence: "Il a les ___ blonds.", answer: "cheveux" }
        ]
      },
      dragDrop: {
        articles: ["tête", "yeux", "nez", "bouche"],
        words: [
          { word: "Kopf", correct: "tête" },
          { word: "Augen", correct: "yeux" },
          { word: "Mund", correct: "bouche" }
        ]
      },
      matching: {
        articles: ["la tête", "les yeux", "le nez"],
        words: [
          { word: "Kopf", translation: "", correct: "la tête" },
          { word: "Augen", translation: "", correct: "les yeux" },
          { word: "Nase", translation: "", correct: "le nez" }
        ]
      }
    }
  },
  {
    id: "weather",
    title: "Wetter",
    subtitle: "Wetterphänomene beschreiben",
    description: "Das Wetter auf Französisch beschreiben",
    icon: "fas fa-cloud-sun",
    iconColor: "text-blue-400",
    bgColor: "bg-blue-50",
    level: "anfänger",
    keywords: ["wetter", "temps", "soleil", "pluie", "neige", "vent", "météo"],
    explanation: {
      title: "Das Wetter beschreiben",
      introduction: "Über das Wetter zu sprechen ist ein wichtiges Alltagsthema. Es gibt verschiedene Strukturen für Wetterphänomene.",
      content: [
        {
          title: "Grundlegende Wetterausdrücke",
          description: "Die wichtigsten Wetterphänomene und ihre Beschreibung.",
          items: [
            { label: "Es ist schön:", value: "Il fait beau", explanation: "Schönes Wetter" },
            { label: "Es regnet:", value: "Il pleut", explanation: "Regen" },
            { label: "Es schneit:", value: "Il neige", explanation: "Schnee" },
            { label: "Es ist heiß:", value: "Il fait chaud", explanation: "Hitze" },
            { label: "Es ist kalt:", value: "Il fait froid", explanation: "Kälte" },
            { label: "Es ist windig:", value: "Il y a du vent", explanation: "Wind" }
          ],
          examples: "Heute: Aujourd'hui il fait beau, Demain il va pleuvoir",
          detailedExamples: [
            {
              french: "Il fait très froid en hiver",
              german: "Im Winter ist es sehr kalt",
              explanation: "Jahreszeit + Wetter"
            },
            {
              french: "Quel temps fait-il?",
              german: "Wie ist das Wetter?",
              explanation: "Nach dem Wetter fragen"
            }
          ],
          rules: [
            "Il fait + Adjektiv für Temperaturen",
            "Il + Verb für Wetterphänomene",
            "Il y a + Substantiv für bestimmte Wetterereignisse"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie sagt man 'Es regnet'?",
        sentence: "",
        options: ["Il fait pluie", "Il pleut", "Il y a pluie"],
        correct: 1,
        explanation: "Il pleut ist die richtige Form für 'es regnet'."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il ____ très chaud aujourd'hui.", answer: "fait" },
          { sentence: "Il ____ depuis ce matin.", answer: "pleut" },
          { sentence: "Il ____ en hiver.", answer: "neige" }
        ]
      },
      dragDrop: {
        articles: ["fait beau", "pleut", "neige", "fait froid"],
        words: [
          { word: "schönes Wetter", correct: "fait beau" },
          { word: "Regen", correct: "pleut" },
          { word: "Kälte", correct: "fait froid" }
        ]
      },
      matching: {
        articles: ["Il fait chaud", "Il pleut", "Il neige"],
        words: [
          { word: "Es ist heiß", translation: "", correct: "Il fait chaud" },
          { word: "Es regnet", translation: "", correct: "Il pleut" },
          { word: "Es schneit", translation: "", correct: "Il neige" }
        ]
      }
    }
  },
  {
    id: "food-drinks",
    title: "Essen und Trinken",
    subtitle: "Lebensmittel und Getränke",
    description: "Speisen und Getränke benennen und bestellen",
    icon: "fas fa-utensils",
    iconColor: "text-red-600",
    bgColor: "bg-red-100",
    level: "anfänger",
    keywords: ["essen", "trinken", "nourriture", "boisson", "pain", "eau", "restaurant"],
    explanation: {
      title: "Essen und Trinken",
      introduction: "Lebensmittel zu kennen ist essentiell für den Alltag, Einkaufen und Restaurantbesuche. Viele Nahrungsmittel haben besondere Artikel.",
      content: [
        {
          title: "Grundnahrungsmittel",
          description: "Die wichtigsten Lebensmittel des täglichen Bedarfs.",
          items: [
            { label: "Brot:", value: "le pain", explanation: "acheter du pain" },
            { label: "Wasser:", value: "l'eau (f.)", explanation: "boire de l'eau" },
            { label: "Milch:", value: "le lait", explanation: "un verre de lait" },
            { label: "Fleisch:", value: "la viande", explanation: "manger de la viande" },
            { label: "Gemüse:", value: "les légumes", explanation: "aimer les légumes" },
            { label: "Obst:", value: "les fruits", explanation: "des fruits frais" }
          ],
          examples: "Einkaufen: Je voudrais du pain, Avez-vous des pommes?",
          detailedExamples: [
            {
              french: "Je prends un café et un croissant",
              german: "Ich nehme einen Kaffee und ein Croissant",
              explanation: "Im Café bestellen"
            },
            {
              french: "Il mange des légumes tous les jours",
              german: "Er isst jeden Tag Gemüse",
              explanation: "Essgewohnheiten beschreiben"
            }
          ],
          rules: [
            "Bei unbestimmten Mengen: du/de la/des",
            "Nach Verneinung: de/d' statt du/de la/des",
            "Getränke meist männlich, Ausnahme: l'eau"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Was passt: 'Je bois ___'?",
        sentence: "",
        options: ["du eau", "de l'eau", "de eau"],
        correct: 1,
        explanation: "de l'eau ist korrekt (eau beginnt mit Vokal)."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Je mange ___ pain.", answer: "du" },
          { sentence: "Elle boit ___ lait.", answer: "du" },
          { sentence: "Nous aimons ___ fruits.", answer: "les" }
        ]
      },
      dragDrop: {
        articles: ["du pain", "de l'eau", "des légumes", "de la viande"],
        words: [
          { word: "Brot essen", correct: "du pain" },
          { word: "Wasser trinken", correct: "de l'eau" },
          { word: "Gemüse", correct: "des légumes" }
        ]
      },
      matching: {
        articles: ["le pain", "l'eau", "la viande"],
        words: [
          { word: "Brot", translation: "", correct: "le pain" },
          { word: "Wasser", translation: "", correct: "l'eau" },
          { word: "Fleisch", translation: "", correct: "la viande" }
        ]
      }
    }
  },
  {
    id: "demonstrative-pronouns",
    title: "Demonstrativpronomen",
    subtitle: "ce, cette, ces, celui, celle, ceux...",
    description: "Hinweisende Fürwörter im Französischen",
    icon: "fas fa-hand-point-right",
    iconColor: "text-indigo-600",
    bgColor: "bg-indigo-100",
    level: "mittelstufe",
    keywords: ["demonstrativ", "ce", "cette", "ces", "celui", "celle", "hinweisend"],
    explanation: {
      title: "Demonstrativpronomen im Französischen",
      introduction: "Demonstrativpronomen sind hinweisende Fürwörter, die auf bestimmte Personen oder Gegenstände zeigen. Sie ersetzen Substantive und richten sich nach Geschlecht und Zahl des ersetzten Wortes. Im Französischen gibt es verschiedene Formen je nach ihrer Funktion im Satz.",
      content: [
        {
          title: "Demonstrativbegleiter (ce, cette, ces)",
          description: "Diese stehen vor Substantiven und begleiten sie.",
          items: [
            { label: "männlich Singular:", value: "ce", explanation: "ce livre, ce garçon" },
            { label: "weiblich Singular:", value: "cette", explanation: "cette maison, cette fille" },
            { label: "Plural (beide):", value: "ces", explanation: "ces livres, ces maisons" },
            { label: "vor Vokal (m.):", value: "cet", explanation: "cet homme, cet ami" }
          ],
          examples: "Beispiele: ce matin, cette année, ces enfants, cet après-midi",
          detailedExamples: [
            {
              french: "Ce livre est intéressant",
              german: "Dieses Buch ist interessant",
              explanation: "ce vor männlichem Substantiv"
            },
            {
              french: "Cette voiture est rouge",
              german: "Dieses Auto ist rot",
              explanation: "cette vor weiblichem Substantiv"
            }
          ],
          rules: [
            "ce wird zu cet vor Vokal oder stummem h",
            "ces ist für alle Pluralformen",
            "Demonstrativbegleiter stehen immer vor dem Substantiv"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welcher Demonstrativbegleiter passt?",
        sentence: "___ homme travaille ici.",
        options: ["ce", "cet", "cette"],
        correct: 1,
        explanation: "cet homme - vor Vokal wird ce zu cet."
      },
      fillInBlanks: {
        questions: [
          { sentence: "___ maison est belle.", answer: "Cette" },
          { sentence: "___ enfants jouent.", answer: "Ces" },
          { sentence: "___ ami est sympa.", answer: "Cet" }
        ]
      },
      dragDrop: {
        articles: ["ce", "cette", "ces", "cet"],
        words: [
          { word: "livre", correct: "ce" },
          { word: "école", correct: "cette" },
          { word: "homme", correct: "cet" }
        ]
      },
      matching: {
        articles: ["ce matin", "cette année", "ces jours"],
        words: [
          { word: "heute Morgen", translation: "", correct: "ce matin" },
          { word: "dieses Jahr", translation: "", correct: "cette année" },
          { word: "diese Tage", translation: "", correct: "ces jours" }
        ]
      }
    }
  },
  {
    id: "conditional",
    title: "Konditional",
    subtitle: "Le conditionnel - Bedingungsform",
    description: "Höflichkeit und hypothetische Situationen ausdrücken",
    icon: "fas fa-question-circle",
    iconColor: "text-purple-600",
    bgColor: "bg-purple-100",
    level: "fortgeschritten",
    keywords: ["konditional", "conditionnel", "höflichkeit", "bedingung", "hypothese"],
    explanation: {
      title: "Das Konditional im Französischen",
      introduction: "Das Konditional wird verwendet, um Höflichkeit auszudrücken, Wünsche zu äußern oder hypothetische Situationen zu beschreiben. Es entspricht dem deutschen 'würde' + Infinitiv oder dem Konjunktiv II.",
      content: [
        {
          title: "Bildung des Konditionals",
          description: "Das Konditional wird mit dem Infinitiv + Imperfekt-Endungen gebildet.",
          items: [
            { label: "je", value: "Infinitiv + ais", explanation: "je parlerais" },
            { label: "tu", value: "Infinitiv + ais", explanation: "tu finirais" },
            { label: "il/elle", value: "Infinitiv + ait", explanation: "il vendrait" },
            { label: "nous", value: "Infinitiv + ions", explanation: "nous aimerions" },
            { label: "vous", value: "Infinitiv + iez", explanation: "vous pourriez" },
            { label: "ils/elles", value: "Infinitiv + aient", explanation: "elles viendraient" }
          ],
          examples: "Beispiele: Je voudrais un café, Tu pourrais m'aider?",
          detailedExamples: [
            {
              french: "Pourriez-vous m'aider?",
              german: "Könnten Sie mir helfen?",
              explanation: "Höfliche Bitte mit Konditional"
            },
            {
              french: "J'aimerais voyager",
              german: "Ich würde gerne reisen",
              explanation: "Wunsch mit Konditional ausdrücken"
            }
          ],
          rules: [
            "Bei Verben auf -re fällt das stumme -e weg",
            "Unregelmäßige Verben haben besondere Stämme",
            "Endungen sind wie im Imperfekt"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Bilde das Konditional:",
        sentence: "Je _____ vous aider.",
        options: ["voudrais", "voudrai", "voulais"],
        correct: 0,
        explanation: "voudrais ist das Konditional von vouloir."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Tu _____ venir? (pouvoir)", answer: "pourrais" },
          { sentence: "Nous _____ partir. (aimer)", answer: "aimerions" },
          { sentence: "Il _____ du temps. (avoir)", answer: "aurait" }
        ]
      },
      dragDrop: {
        articles: ["voudrais", "pourriez", "aimeraient", "serais"],
        words: [
          { word: "je _____ (wollen)", correct: "voudrais" },
          { word: "vous _____ (können)", correct: "pourriez" },
          { word: "ils _____ (mögen)", correct: "aimeraient" }
        ]
      },
      matching: {
        articles: ["Je voudrais", "Tu pourrais", "Il aimerait"],
        words: [
          { word: "Ich möchte", translation: "", correct: "Je voudrais" },
          { word: "Du könntest", translation: "", correct: "Tu pourrais" },
          { word: "Er würde mögen", translation: "", correct: "Il aimerait" }
        ]
      }
    }
  },
  {
    id: "partitive-articles",
    title: "Teilungsartikel",
    subtitle: "du, de la, de l', des - unbestimmte Mengen",
    description: "Teilungsartikel für unbestimmte Mengen",
    icon: "fas fa-divide",
    iconColor: "text-orange-600",
    bgColor: "bg-orange-100",
    level: "mittelstufe",
    keywords: ["teilung", "du", "de la", "des", "menge", "unbestimmt"],
    explanation: {
      title: "Teilungsartikel im Französischen",
      introduction: "Teilungsartikel werden verwendet, um unbestimmte Mengen von nicht zählbaren Substantiven auszudrücken. Sie entsprechen oft dem deutschen 'etwas' oder gar keinem Artikel. Sie sind im Französischen viel häufiger als im Deutschen.",
      content: [
        {
          title: "Die vier Teilungsartikel",
          description: "Teilungsartikel richten sich nach dem Geschlecht des Substantivs.",
          items: [
            { label: "männlich:", value: "du", explanation: "du pain, du lait" },
            { label: "weiblich:", value: "de la", explanation: "de la viande, de la musique" },
            { label: "vor Vokal:", value: "de l'", explanation: "de l'eau, de l'argent" },
            { label: "Plural:", value: "des", explanation: "des légumes, des fruits" }
          ],
          examples: "Beispiele: Je mange du poisson, Il boit de l'eau",
          detailedExamples: [
            {
              french: "Je bois du café",
              german: "Ich trinke Kaffee",
              explanation: "Unbestimmte Menge Kaffee"
            },
            {
              french: "Elle mange de la salade",
              german: "Sie isst Salat",
              explanation: "Unbestimmte Menge Salat"
            }
          ],
          rules: [
            "Nach Verneinung wird du/de la/des zu de/d'",
            "Nach Mengenangaben steht nur de",
            "Bei zählbaren Dingen im Plural: des"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welcher Teilungsartikel ist richtig?",
        sentence: "Il mange ___ viande.",
        options: ["du", "de la", "de l'"],
        correct: 1,
        explanation: "de la viande - viande ist weiblich."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Je bois ___ eau.", answer: "de l'" },
          { sentence: "Tu manges ___ pain.", answer: "du" },
          { sentence: "Nous achetons ___ légumes.", answer: "des" }
        ]
      },
      dragDrop: {
        articles: ["du", "de la", "de l'", "des"],
        words: [
          { word: "café", correct: "du" },
          { word: "eau", correct: "de l'" },
          { word: "fruits", correct: "des" }
        ]
      },
      matching: {
        articles: ["du pain", "de la confiture", "de l'eau"],
        words: [
          { word: "Brot", translation: "", correct: "du pain" },
          { word: "Marmelade", translation: "", correct: "de la confiture" },
          { word: "Wasser", translation: "", correct: "de l'eau" }
        ]
      }
    }
  },
  {
    id: "imperative",
    title: "Imperativ",
    subtitle: "Befehle und Aufforderungen",
    description: "Befehlsform für Anweisungen und Bitten",
    icon: "fas fa-exclamation",
    iconColor: "text-red-600",
    bgColor: "bg-red-100",
    level: "mittelstufe",
    keywords: ["imperativ", "befehl", "aufforderung", "anweisung", "bitte"],
    explanation: {
      title: "Der Imperativ im Französischen",
      introduction: "Der Imperativ wird verwendet, um Befehle, Aufforderungen, Bitten oder Ratschläge auszudrücken. Es gibt nur drei Formen: tu, nous und vous. Die Pronomen werden weggelassen und bei tu-Form entfällt oft das -s.",
      content: [
        {
          title: "Bildung des Imperativs",
          description: "Der Imperativ wird aus dem Präsens ohne Pronomen gebildet.",
          items: [
            { label: "tu-Form:", value: "ohne -s bei -er Verben", explanation: "Parle! (Sprich!)" },
            { label: "nous-Form:", value: "wie Präsens", explanation: "Parlons! (Sprechen wir!)" },
            { label: "vous-Form:", value: "wie Präsens", explanation: "Parlez! (Sprechen Sie!)" },
            { label: "Verneinung:", value: "ne + Imperativ + pas", explanation: "Ne parle pas!" }
          ],
          examples: "Beispiele: Écoute! Écoutons! Écoutez! N'écoute pas!",
          detailedExamples: [
            {
              french: "Mange ta soupe!",
              german: "Iss deine Suppe!",
              explanation: "Befehl an eine Person (tu)"
            },
            {
              french: "Allons au cinéma!",
              german: "Gehen wir ins Kino!",
              explanation: "Vorschlag mit nous-Form"
            }
          ],
          rules: [
            "Bei -er Verben fällt das -s in der tu-Form weg",
            "être, avoir und savoir sind unregelmäßig",
            "Objektpronomen stehen nach dem Imperativ"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Bilde den Imperativ:",
        sentence: "_____ bien! (tu - écouter)",
        options: ["Écoutes", "Écoute", "Écoutez"],
        correct: 1,
        explanation: "Écoute - bei -er Verben fällt das -s weg."
      },
      fillInBlanks: {
        questions: [
          { sentence: "_____ tes devoirs! (faire - tu)", answer: "Fais" },
          { sentence: "_____ du sport! (faire - nous)", answer: "Faisons" },
          { sentence: "_____ pas! (partir - tu)", answer: "Ne pars" }
        ]
      },
      dragDrop: {
        articles: ["Mange!", "Parlons!", "Venez!", "N'oublie pas!"],
        words: [
          { word: "Iss! (tu)", correct: "Mange!" },
          { word: "Sprechen wir!", correct: "Parlons!" },
          { word: "Kommen Sie!", correct: "Venez!" }
        ]
      },
      matching: {
        articles: ["Écoute!", "Regardez!", "Allons-y!"],
        words: [
          { word: "Hör zu!", translation: "", correct: "Écoute!" },
          { word: "Schauen Sie!", translation: "", correct: "Regardez!" },
          { word: "Gehen wir!", translation: "", correct: "Allons-y!" }
        ]
      }
    }
  },
  {
    id: "reflexive-verbs",
    title: "Reflexive Verben",
    subtitle: "se laver, se lever, s'habiller...",
    description: "Verben mit Reflexivpronomen",
    icon: "fas fa-mirror",
    iconColor: "text-teal-600",
    bgColor: "bg-teal-100",
    level: "mittelstufe",
    keywords: ["reflexiv", "se", "sich", "waschen", "anziehen", "pronomen"],
    explanation: {
      title: "Reflexive Verben im Französischen",
      introduction: "Reflexive Verben beschreiben Handlungen, die man an sich selbst vollzieht. Sie werden mit Reflexivpronomen (me, te, se, nous, vous, se) gebildet, die vor dem Verb stehen. Viele Alltagsverben sind reflexiv.",
      content: [
        {
          title: "Reflexivpronomen und Konjugation",
          description: "Die Reflexivpronomen passen sich an das Subjekt an.",
          items: [
            { label: "je", value: "me", explanation: "je me lave" },
            { label: "tu", value: "te", explanation: "tu te lèves" },
            { label: "il/elle", value: "se", explanation: "elle se coiffe" },
            { label: "nous", value: "nous", explanation: "nous nous habillons" },
            { label: "vous", value: "vous", explanation: "vous vous reposez" },
            { label: "ils/elles", value: "se", explanation: "ils se douchent" }
          ],
          examples: "Beispiele: Je me réveille à 7h, Tu te brosses les dents",
          detailedExamples: [
            {
              french: "Elle se maquille",
              german: "Sie schminkt sich",
              explanation: "Reflexive Handlung an sich selbst"
            },
            {
              french: "Nous nous amusons",
              german: "Wir amüsieren uns",
              explanation: "Reflexives Verb im Plural"
            }
          ],
          rules: [
            "Reflexivpronomen stehen vor dem konjugierten Verb",
            "Im Passé Composé wird être als Hilfsverb verwendet",
            "Vor Vokal: me/te/se werden zu m'/t'/s'"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welches Reflexivpronomen passt?",
        sentence: "Il ___ lave les mains.",
        options: ["me", "te", "se"],
        correct: 2,
        explanation: "se - für il/elle wird 'se' verwendet."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Je ___ réveille tôt.", answer: "me" },
          { sentence: "Tu ___ habilles vite.", answer: "t'" },
          { sentence: "Nous ___ amusons bien.", answer: "nous" }
        ]
      },
      dragDrop: {
        articles: ["me lave", "te coiffes", "se repose", "nous habillons"],
        words: [
          { word: "je _____ (waschen)", correct: "me lave" },
          { word: "tu _____ (kämmen)", correct: "te coiffes" },
          { word: "il _____ (ausruhen)", correct: "se repose" }
        ]
      },
      matching: {
        articles: ["se lever", "s'habiller", "se laver"],
        words: [
          { word: "aufstehen", translation: "", correct: "se lever" },
          { word: "sich anziehen", translation: "", correct: "s'habiller" },
          { word: "sich waschen", translation: "", correct: "se laver" }
        ]
      }
    }
  },
  {
    id: "comparative-superlative",
    title: "Komparativ und Superlativ",
    subtitle: "plus... que, le plus..., moins... que",
    description: "Vergleichsformen der Adjektive",
    icon: "fas fa-balance-scale",
    iconColor: "text-yellow-600",
    bgColor: "bg-yellow-100",
    level: "mittelstufe",
    keywords: ["komparativ", "superlativ", "plus", "moins", "que", "vergleich"],
    explanation: {
      title: "Komparativ und Superlativ",
      introduction: "Mit Komparativ und Superlativ können Eigenschaften verglichen werden. Der Komparativ vergleicht zwei Dinge, der Superlativ drückt den höchsten oder niedrigsten Grad aus. Im Französischen wird dies mit plus, moins und aussi ausgedrückt.",
      content: [
        {
          title: "Komparativ (Vergleichsstufe)",
          description: "Zum Vergleichen von zwei Personen oder Dingen.",
          items: [
            { label: "Überlegenheit:", value: "plus... que", explanation: "Elle est plus grande que lui" },
            { label: "Unterlegenheit:", value: "moins... que", explanation: "Il est moins rapide que toi" },
            { label: "Gleichheit:", value: "aussi... que", explanation: "Tu es aussi intelligent que moi" },
            { label: "Unregelmäßig:", value: "bon → meilleur", explanation: "Ce livre est meilleur" }
          ],
          examples: "Beispiele: Paris est plus grand que Lyon, Il court aussi vite que toi",
          detailedExamples: [
            {
              french: "Ma sœur est plus âgée que moi",
              german: "Meine Schwester ist älter als ich",
              explanation: "Komparativ der Überlegenheit"
            },
            {
              french: "Ce film est moins intéressant que l'autre",
              german: "Dieser Film ist weniger interessant als der andere",
              explanation: "Komparativ der Unterlegenheit"
            }
          ],
          rules: [
            "plus/moins + Adjektiv + que",
            "aussi + Adjektiv + que (nur bei Gleichheit)",
            "bon/bien haben unregelmäßige Formen"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Bilde den Komparativ:",
        sentence: "Elle est ___ intelligente ___ lui.",
        options: ["plus... que", "plus... de", "aussi... de"],
        correct: 0,
        explanation: "plus... que für Überlegenheit."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il est ___ grand ___ moi.", answer: "plus... que" },
          { sentence: "Tu es ___ rapide ___ lui.", answer: "aussi... que" },
          { sentence: "Cette voiture est ___.", answer: "meilleure" }
        ]
      },
      dragDrop: {
        articles: ["plus grand", "moins cher", "aussi beau", "meilleur"],
        words: [
          { word: "größer", correct: "plus grand" },
          { word: "billiger", correct: "moins cher" },
          { word: "genauso schön", correct: "aussi beau" }
        ]
      },
      matching: {
        articles: ["le plus grand", "la moins chère", "le meilleur"],
        words: [
          { word: "der größte", translation: "", correct: "le plus grand" },
          { word: "die billigste", translation: "", correct: "la moins chère" },
          { word: "der beste", translation: "", correct: "le meilleur" }
        ]
      }
    }
  },
  {
    id: "imperfect",
    title: "Imperfekt",
    subtitle: "L'imparfait - die Verlaufsvergangenheit",
    description: "Beschreibungen und Gewohnheiten in der Vergangenheit",
    icon: "fas fa-clock",
    iconColor: "text-gray-600",
    bgColor: "bg-gray-100",
    level: "mittelstufe",
    keywords: ["imperfekt", "imparfait", "vergangenheit", "gewohnheit", "beschreibung"],
    explanation: {
      title: "Das Imperfekt im Französischen",
      introduction: "Das Imperfekt beschreibt andauernde Handlungen, Gewohnheiten oder Zustände in der Vergangenheit. Es entspricht dem deutschen 'war dabei zu' oder gewohnheitsmäßigen Handlungen.",
      content: [
        {
          title: "Bildung des Imperfekts",
          description: "Das Imperfekt wird vom nous-Stamm des Präsens gebildet.",
          items: [
            { label: "Stamm:", value: "nous-Form ohne -ons", explanation: "parlons → parl-" },
            { label: "je", value: "Stamm + ais", explanation: "je parlais" },
            { label: "tu", value: "Stamm + ais", explanation: "tu parlais" },
            { label: "il/elle", value: "Stamm + ait", explanation: "il parlait" },
            { label: "nous", value: "Stamm + ions", explanation: "nous parlions" },
            { label: "vous", value: "Stamm + iez", explanation: "vous parliez" },
            { label: "ils/elles", value: "Stamm + aient", explanation: "ils parlaient" }
          ],
          examples: "Beispiele: Je regardais la télé, Nous habitions à Paris",
          rules: [
            "Nur être ist unregelmäßig: j'étais, tu étais...",
            "Beschreibt Hintergründe und Gewohnheiten",
            "Oft mit 'pendant que', 'quand', 'toujours'"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Bilde das Imperfekt:",
        sentence: "Quand j'étais petit, je _____ beaucoup.",
        options: ["joue", "jouais", "ai joué"],
        correct: 1,
        explanation: "jouais - Imperfekt für Gewohnheiten in der Kindheit."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il _____ tous les jours. (travailler)", answer: "travaillait" },
          { sentence: "Nous _____ en France. (habiter)", answer: "habitions" },
          { sentence: "Tu _____ petit. (être)", answer: "étais" }
        ]
      },
      dragDrop: {
        articles: ["regardais", "faisions", "étaient", "aviez"],
        words: [
          { word: "je _____ (schauen)", correct: "regardais" },
          { word: "nous _____ (machen)", correct: "faisions" },
          { word: "ils _____ (sein)", correct: "étaient" }
        ]
      },
      matching: {
        articles: ["j'étais", "tu avais", "il faisait"],
        words: [
          { word: "ich war", translation: "", correct: "j'étais" },
          { word: "du hattest", translation: "", correct: "tu avais" },
          { word: "er machte", translation: "", correct: "il faisait" }
        ]
      }
    }
  },
  {
    id: "adverbs",
    title: "Adverbien",
    subtitle: "Bildung und Verwendung von Adverbien",
    description: "Umstandswörter zur näheren Bestimmung",
    icon: "fas fa-plus",
    iconColor: "text-emerald-600",
    bgColor: "bg-emerald-100",
    level: "mittelstufe",
    keywords: ["adverb", "adverbien", "ment", "umstandswort", "bildung"],
    explanation: {
      title: "Adverbien im Französischen",
      introduction: "Adverbien beschreiben näher, wie, wann, wo oder in welchem Maß etwas geschieht. Sie werden meist aus Adjektiven mit der Endung -ment gebildet, ähnlich dem deutschen -weise oder -lich.",
      content: [
        {
          title: "Bildung der Adverbien",
          description: "Die meisten Adverbien werden aus der weiblichen Form des Adjektivs gebildet.",
          items: [
            { label: "Grundregel:", value: "Adjektiv (f.) + ment", explanation: "lente → lentement" },
            { label: "auf -ant:", value: "-amment", explanation: "élégant → élégamment" },
            { label: "auf -ent:", value: "-emment", explanation: "récent → récemment" },
            { label: "Besondere:", value: "unregelmäßige Formen", explanation: "bon → bien, mauvais → mal" }
          ],
          examples: "Beispiele: rapidement, facilement, vraiment, déjà",
          rules: [
            "Weibliche Adjektivform + ment",
            "Manche Adverbien sind völlig unregelmäßig",
            "Position meist nach dem Verb"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Bilde das Adverb:",
        sentence: "Il parle très ___. (rapide)",
        options: ["rapide", "rapidement", "rapidement"],
        correct: 1,
        explanation: "rapidement - rapide → rapidement."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Elle chante ___. (beau)", answer: "bien" },
          { sentence: "Il conduit ___. (lent)", answer: "lentement" },
          { sentence: "Tu parles ___. (facile)", answer: "facilement" }
        ]
      },
      dragDrop: {
        articles: ["lentement", "facilement", "vraiment", "bien"],
        words: [
          { word: "langsam", correct: "lentement" },
          { word: "leicht", correct: "facilement" },
          { word: "wirklich", correct: "vraiment" }
        ]
      },
      matching: {
        articles: ["rapidement", "difficilement", "heureusement"],
        words: [
          { word: "schnell", translation: "", correct: "rapidement" },
          { word: "schwer", translation: "", correct: "difficilement" },
          { word: "glücklicherweise", translation: "", correct: "heureusement" }
        ]
      }
    }
  },
  {
    id: "direct-indirect-objects",
    title: "Direkte und indirekte Objekte",
    subtitle: "le, la, les, lui, leur - Objektpronomen",
    description: "Ersatz für Akkusativ- und Dativobjekte",
    icon: "fas fa-arrow-right",
    iconColor: "text-cyan-600",
    bgColor: "bg-cyan-100",
    level: "fortgeschritten",
    keywords: ["objekt", "pronomen", "direkt", "indirekt", "le", "la", "lui", "leur"],
    explanation: {
      title: "Direkte und indirekte Objektpronomen",
      introduction: "Objektpronomen ersetzen Substantive, die als direktes oder indirektes Objekt fungieren. Sie stehen vor dem konjugierten Verb und sparen Wiederholungen. Die Wahl hängt von der Verbart ab.",
      content: [
        {
          title: "Direkte Objektpronomen",
          description: "Ersetzen das direkte Objekt (wen oder was?).",
          items: [
            { label: "me/m':", value: "mich", explanation: "Il me voit" },
            { label: "te/t':", value: "dich", explanation: "Je te connais" },
            { label: "le/l':", value: "ihn/es", explanation: "Je le prends" },
            { label: "la/l':", value: "sie/es", explanation: "Il la regarde" },
            { label: "nous:", value: "uns", explanation: "Tu nous appelles" },
            { label: "vous:", value: "euch/Sie", explanation: "Je vous invite" },
            { label: "les:", value: "sie", explanation: "Elle les achète" }
          ],
          examples: "Beispiele: Je le vois, Tu la connais, Il nous invite",
          rules: [
            "Stehen vor dem konjugierten Verb",
            "Bei zusammengesetzten Zeiten vor dem Hilfsverb",
            "Vor Vokal: me/te/le/la werden zu m'/t'/l'/l'"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Ersetze durch ein Pronomen:",
        sentence: "Je regarde la télévision. → Je ___ regarde.",
        options: ["le", "la", "les"],
        correct: 1,
        explanation: "la - télévision ist weiblich."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Je ___ vois. (Paul)", answer: "le" },
          { sentence: "Il ___ appelle. (nous)", answer: "nous" },
          { sentence: "Tu ___ connais? (Marie)", answer: "la" }
        ]
      },
      dragDrop: {
        articles: ["le", "la", "les", "lui"],
        words: [
          { word: "livre → ___", correct: "le" },
          { word: "voiture → ___", correct: "la" },
          { word: "enfants → ___", correct: "les" }
        ]
      },
      matching: {
        articles: ["Je le vois", "Tu la connais", "Il nous invite"],
        words: [
          { word: "Ich sehe ihn", translation: "", correct: "Je le vois" },
          { word: "Du kennst sie", translation: "", correct: "Tu la connais" },
          { word: "Er lädt uns ein", translation: "", correct: "Il nous invite" }
        ]
      }
    }
  },
  {
    id: "pronunciation-liaison",
    title: "Aussprache und Liaison",
    subtitle: "Bindungen zwischen Wörtern",
    description: "Französische Ausspracheregeln und Wortverbindungen",
    icon: "fas fa-volume-up",
    iconColor: "text-pink-600",
    bgColor: "bg-pink-100",
    level: "mittelstufe",
    keywords: ["aussprache", "liaison", "bindung", "phonetik", "stumm"],
    explanation: {
      title: "Aussprache und Liaison im Französischen",
      introduction: "Die Liaison ist eine wichtige Erscheinung im Französischen, bei der normalerweise stumme Endkonsonanten vor Vokalen ausgesprochen werden. Dies verbindet Wörter miteinander und macht die Sprache fließender.",
      content: [
        {
          title: "Grundregeln der Liaison",
          description: "Wann und wie Bindungen gebildet werden.",
          items: [
            { label: "Obligatorisch:", value: "Artikel + Substantiv", explanation: "les‿enfants [le-z‿ɑ̃fɑ̃]" },
            { label: "Häufig:", value: "Adjektiv + Substantiv", explanation: "petit‿ami [pəti-t‿ami]" },
            { label: "Verbindungslaute:", value: "s/x → [z], t → [t], n → [n]", explanation: "nous‿avons [nu-z‿avɔ̃]" },
            { label: "Verboten:", value: "nach et, vor h aspiré", explanation: "et elle (keine Liaison)" }
          ],
          examples: "Beispiele: deux‿ans, trois‿heures, ils‿ont, vous‿êtes",
          rules: [
            "Nur vor Vokalen oder stummem h",
            "s und x werden als [z] ausgesprochen",
            "t wird als [t] ausgesprochen"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wo ist eine Liaison?",
        sentence: "Welches Wortpaar hat eine Liaison?",
        options: ["et elle", "les arbres", "le garçon"],
        correct: 1,
        explanation: "les arbres - s wird als [z] vor Vokal ausgesprochen."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il___ ont [il-z‿ɔ̃] drei Jahre", answer: "s" },
          { sentence: "Deu___ ans [dø-z‿ɑ̃]", answer: "x" },
          { sentence: "Peti___ ami [pəti-t‿ami]", answer: "t" }
        ]
      },
      dragDrop: {
        articles: ["[z]", "[t]", "[n]", "keine"],
        words: [
          { word: "les‿enfants", correct: "[z]" },
          { word: "petit‿ami", correct: "[t]" },
          { word: "et elle", correct: "keine" }
        ]
      },
      matching: {
        articles: ["deux‿ans", "ils‿ont", "tout‿à‿fait"],
        words: [
          { word: "[dø-z‿ɑ̃]", translation: "", correct: "deux‿ans" },
          { word: "[il-z‿ɔ̃]", translation: "", correct: "ils‿ont" },
          { word: "[tu-t‿a‿fɛ]", translation: "", correct: "tout‿à‿fait" }
        ]
      }
    }
  },
  {
    id: "relative-pronouns",
    title: "Relativpronomen",
    subtitle: "qui, que, dont, où - Verbindung von Sätzen",
    description: "Relativsätze zur Beschreibung und Erklärung",
    icon: "fas fa-link",
    iconColor: "text-violet-600",
    bgColor: "bg-violet-100",
    level: "fortgeschritten",
    keywords: ["relativ", "qui", "que", "dont", "où", "relativsatz"],
    explanation: {
      title: "Relativpronomen im Französischen",
      introduction: "Relativpronomen verbinden Haupt- und Nebensätze und vermeiden Wiederholungen. Sie beziehen sich auf ein Substantiv im Hauptsatz und leiten einen beschreibenden Nebensatz ein.",
      content: [
        {
          title: "Die wichtigsten Relativpronomen",
          description: "Verschiedene Relativpronomen für verschiedene Funktionen.",
          items: [
            { label: "qui:", value: "wer, der/die/das (Subjekt)", explanation: "L'homme qui parle" },
            { label: "que:", value: "den/die/das (Objekt)", explanation: "Le livre que je lis" },
            { label: "dont:", value: "dessen, von dem", explanation: "L'ami dont je parle" },
            { label: "où:", value: "wo, als (Zeit/Ort)", explanation: "La ville où j'habite" }
          ],
          examples: "Beispiele: C'est l'homme qui travaille ici, Le film que nous regardons",
          rules: [
            "qui = Subjekt des Relativsatzes",
            "que = direktes Objekt des Relativsatzes",
            "dont ersetzt de + Substantiv"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welches Relativpronomen passt?",
        sentence: "C'est le livre ___ je lis.",
        options: ["qui", "que", "dont"],
        correct: 1,
        explanation: "que - 'livre' ist direktes Objekt von 'lire'."
      },
      fillInBlanks: {
        questions: [
          { sentence: "L'homme ___ parle est mon père.", answer: "qui" },
          { sentence: "La ville ___ j'habite est belle.", answer: "où" },
          { sentence: "L'ami ___ je parle s'appelle Paul.", answer: "dont" }
        ]
      },
      dragDrop: {
        articles: ["qui", "que", "dont", "où"],
        words: [
          { word: "L'homme ___ travaille", correct: "qui" },
          { word: "Le film ___ je regarde", correct: "que" },
          { word: "L'école ___ j'étudie", correct: "où" }
        ]
      },
      matching: {
        articles: ["qui parle", "que je vois", "dont je parle"],
        words: [
          { word: "der spricht", translation: "", correct: "qui parle" },
          { word: "den ich sehe", translation: "", correct: "que je vois" },
          { word: "von dem ich spreche", translation: "", correct: "dont je parle" }
        ]
      }
    }
  },
  {
    id: "subjunctive",
    title: "Subjonctif",
    subtitle: "Der Konjunktiv - Meinungen und Gefühle",
    description: "Subjektive Aussagen und Meinungsäußerungen",
    icon: "fas fa-heart",
    iconColor: "text-rose-600",
    bgColor: "bg-rose-100",
    level: "fortgeschritten",
    keywords: ["subjonctif", "konjunktiv", "meinung", "gefühl", "subjektiv"],
    explanation: {
      title: "Der Subjonctif im Französischen",
      introduction: "Der Subjonctif drückt subjektive Einstellungen, Meinungen, Gefühle oder Zweifel aus. Er steht oft nach bestimmten Verben und Ausdrücken, die eine persönliche Bewertung beinhalten.",
      content: [
        {
          title: "Verwendung des Subjonctif",
          description: "Wann der Subjonctif verwendet wird.",
          items: [
            { label: "Gefühle:", value: "je suis content que...", explanation: "je suis content qu'il vienne" },
            { label: "Meinungen:", value: "je pense que... (verneint)", explanation: "je ne pense pas qu'il soit là" },
            { label: "Zweifel:", value: "je doute que...", explanation: "je doute qu'il puisse venir" },
            { label: "Notwendigkeit:", value: "il faut que...", explanation: "il faut que tu partes" }
          ],
          examples: "Beispiele: Je veux qu'il vienne, Il faut que tu fasses attention",
          rules: [
            "Nach que in bestimmten Kontexten",
            "Bildung meist vom ils-Stamm des Präsens",
            "Être und avoir sind unregelmäßig"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Braucht man hier Subjonctif?",
        sentence: "Je veux qu'il ___.",
        options: ["vient", "vienne", "viendra"],
        correct: 1,
        explanation: "vienne - nach 'vouloir que' steht Subjonctif."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il faut que tu ___. (faire)", answer: "fasses" },
          { sentence: "Je doute qu'il ___. (être)", answer: "soit" },
          { sentence: "Je suis content qu'elle ___. (venir)", answer: "vienne" }
        ]
      },
      dragDrop: {
        articles: ["soit", "fasse", "vienne", "puisse"],
        words: [
          { word: "qu'il ___ (être)", correct: "soit" },
          { word: "que tu ___ (faire)", correct: "fasse" },
          { word: "qu'elle ___ (venir)", correct: "vienne" }
        ]
      },
      matching: {
        articles: ["qu'il soit", "que tu fasses", "qu'elle vienne"],
        words: [
          { word: "dass er ist", translation: "", correct: "qu'il soit" },
          { word: "dass du machst", translation: "", correct: "que tu fasses" },
          { word: "dass sie kommt", translation: "", correct: "qu'elle vienne" }
        ]
      }
    }
  },
  {
    id: "simple-future",
    title: "Futur Simple",
    subtitle: "Die einfache Zukunft",
    description: "Bildung und Verwendung des Futur Simple",
    icon: "fas fa-forward",
    iconColor: "text-blue-600",
    bgColor: "bg-blue-100",
    level: "mittelstufe",
    keywords: ["futur", "zukunft", "simple", "werden"],
    explanation: {
      title: "Das Futur Simple im Französischen",
      introduction: "Das Futur Simple drückt zukünftige Handlungen aus und entspricht dem deutschen 'werden + Infinitiv'. Es wird durch Anhängen der Futurendungen an den Infinitiv gebildet.",
      content: [
        {
          title: "Bildung des Futur Simple",
          description: "Infinitiv + Futurendungen",
          items: [
            { label: "je", value: "Infinitiv + ai", explanation: "je parlerai" },
            { label: "tu", value: "Infinitiv + as", explanation: "tu finiras" },
            { label: "il/elle", value: "Infinitiv + a", explanation: "il vendra" },
            { label: "nous", value: "Infinitiv + ons", explanation: "nous irons" },
            { label: "vous", value: "Infinitiv + ez", explanation: "vous pourrez" },
            { label: "ils/elles", value: "Infinitiv + ont", explanation: "elles viendront" }
          ],
          examples: "Beispiele: Je partirai demain, Tu viendras avec nous",
          rules: [
            "Bei Verben auf -re fällt das stumme -e weg",
            "Viele unregelmäßige Verben haben besondere Stämme",
            "Zeitangaben: demain, l'année prochaine, dans une semaine"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Bilde das Futur Simple:",
        sentence: "Demain, je _____ au cinéma.",
        options: ["irai", "vais", "allais"],
        correct: 0,
        explanation: "irai ist das Futur Simple von aller."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Tu _____ demain. (venir)", answer: "viendras" },
          { sentence: "Nous _____ nos devoirs. (faire)", answer: "ferons" },
          { sentence: "Elle _____ en France. (aller)", answer: "ira" }
        ]
      },
      dragDrop: {
        articles: ["parlerai", "finiras", "sera", "auront"],
        words: [
          { word: "je _____ (sprechen)", correct: "parlerai" },
          { word: "tu _____ (beenden)", correct: "finiras" },
          { word: "il _____ (sein)", correct: "sera" }
        ]
      },
      matching: {
        articles: ["je ferai", "tu iras", "il aura"],
        words: [
          { word: "ich werde machen", translation: "", correct: "je ferai" },
          { word: "du wirst gehen", translation: "", correct: "tu iras" },
          { word: "er wird haben", translation: "", correct: "il aura" }
        ]
      }
    }
  },
  {
    id: "colors-numbers",
    title: "Farben und Zahlen",
    subtitle: "Les couleurs et les nombres",
    description: "Grundwortschatz: Farben und Zahlen auf Französisch",
    icon: "fas fa-palette",
    iconColor: "text-rainbow-600",
    bgColor: "bg-rainbow-100",
    level: "anfaenger",
    keywords: ["farben", "zahlen", "couleurs", "nombres", "wortschatz"],
    explanation: {
      title: "Farben und Zahlen im Französischen",
      introduction: "Farben und Zahlen gehören zum Grundwortschatz jeder Sprache. Französische Farben passen sich wie Adjektive an das Geschlecht an, während Zahlen meist unveränderlich sind.",
      content: [
        {
          title: "Die wichtigsten Farben",
          description: "Grundfarben mit Geschlechtsanpassung",
          items: [
            { label: "rot:", value: "rouge", explanation: "rouge bleibt unverändert" },
            { label: "blau:", value: "bleu(e)", explanation: "bleu → bleue (f.)" },
            { label: "grün:", value: "vert(e)", explanation: "vert → verte (f.)" },
            { label: "gelb:", value: "jaune", explanation: "jaune bleibt unverändert" },
            { label: "schwarz:", value: "noir(e)", explanation: "noir → noire (f.)" },
            { label: "weiß:", value: "blanc/blanche", explanation: "blanc → blanche (f.)" }
          ],
          examples: "Beispiele: une voiture rouge, un pull bleu, des chaussures noires",
          rules: [
            "Farben stehen meist nach dem Substantiv",
            "Manche Farben sind unveränderlich (orange, marron)",
            "Im Plural wird meist -s angehängt"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welche Form ist richtig?",
        sentence: "Elle porte une robe ___.",
        options: ["bleu", "bleue", "bleus"],
        correct: 1,
        explanation: "bleue - robe ist weiblich, also bleue."
      },
      fillInBlanks: {
        questions: [
          { sentence: "J'ai une voiture ___. (rot)", answer: "rouge" },
          { sentence: "Ses yeux sont ___. (grün - f.)", answer: "verts" },
          { sentence: "Il y a ___ pommes. (drei)", answer: "trois" }
        ]
      },
      dragDrop: {
        articles: ["rouge", "bleue", "verts", "noires"],
        words: [
          { word: "une pomme ___", correct: "rouge" },
          { word: "la mer ___", correct: "bleue" },
          { word: "des arbres ___", correct: "verts" }
        ]
      },
      matching: {
        articles: ["rouge", "deux", "vert"],
        words: [
          { word: "rot", translation: "", correct: "rouge" },
          { word: "zwei", translation: "", correct: "deux" },
          { word: "grün", translation: "", correct: "vert" }
        ]
      }
    }
  },
  {
    id: "family-relationships",
    title: "Familie und Verwandtschaft",
    subtitle: "La famille et les relations",
    description: "Familienmitglieder und Verwandtschaftsbeziehungen",
    icon: "fas fa-users",
    iconColor: "text-pink-600",
    bgColor: "bg-pink-100",
    level: "anfaenger",
    keywords: ["familie", "verwandtschaft", "famille", "parents", "enfants"],
    explanation: {
      title: "Familie und Verwandtschaft",
      introduction: "Die Familie ist ein wichtiges Thema im alltäglichen Gespräch. Französische Verwandtschaftsbezeichnungen haben oft verschiedene Formen für männlich und weiblich.",
      content: [
        {
          title: "Familienmitglieder",
          description: "Die wichtigsten Verwandtschaftsbezeichnungen",
          items: [
            { label: "Vater:", value: "le père", explanation: "Papa: le papa" },
            { label: "Mutter:", value: "la mère", explanation: "Mama: la maman" },
            { label: "Sohn:", value: "le fils", explanation: "ausgesprochen [fis]" },
            { label: "Tochter:", value: "la fille", explanation: "auch: das Mädchen" },
            { label: "Bruder:", value: "le frère", explanation: "kleiner Bruder: le petit frère" },
            { label: "Schwester:", value: "la sœur", explanation: "große Schwester: la grande sœur" }
          ],
          examples: "Beispiele: Mon père travaille, Ma sœur étudie, Mes parents sont gentils",
          rules: [
            "Possessivbegleiter: mon/ma/mes, ton/ta/tes, son/sa/ses",
            "les parents = die Eltern oder die Verwandten",
            "famille ist weiblich: ma famille"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie sagt man 'meine Schwester'?",
        sentence: "_____ sœur est très sympa.",
        options: ["Mon", "Ma", "Mes"],
        correct: 1,
        explanation: "Ma sœur - sœur ist weiblich."
      },
      fillInBlanks: {
        questions: [
          { sentence: "___ père est médecin.", answer: "Mon" },
          { sentence: "___ parents sont en vacances.", answer: "Mes" },
          { sentence: "C'est ___ fille.", answer: "ma" }
        ]
      },
      dragDrop: {
        articles: ["père", "mère", "frère", "sœur"],
        words: [
          { word: "Vater", correct: "père" },
          { word: "Mutter", correct: "mère" },
          { word: "Bruder", correct: "frère" }
        ]
      },
      matching: {
        articles: ["mon père", "ma mère", "mes parents"],
        words: [
          { word: "mein Vater", translation: "", correct: "mon père" },
          { word: "meine Mutter", translation: "", correct: "ma mère" },
          { word: "meine Eltern", translation: "", correct: "mes parents" }
        ]
      }
    }
  },
  {
    id: "weather-seasons",
    title: "Wetter und Jahreszeiten",
    subtitle: "Le temps et les saisons",
    description: "Wetterausdrücke und Jahreszeiten beschreiben",
    icon: "fas fa-sun",
    iconColor: "text-yellow-600",
    bgColor: "bg-yellow-100",
    level: "anfaenger",
    keywords: ["wetter", "jahreszeiten", "temps", "saisons", "météo"],
    explanation: {
      title: "Wetter und Jahreszeiten",
      introduction: "Das Wetter zu beschreiben ist ein wichtiger Teil der alltäglichen Kommunikation. Im Französischen verwendet man oft unpersönliche Ausdrücke mit 'il fait' oder 'il y a'.",
      content: [
        {
          title: "Wetterausdrücke",
          description: "Die wichtigsten Ausdrücke für das Wetter",
          items: [
            { label: "schönes Wetter:", value: "il fait beau", explanation: "Es ist schön" },
            { label: "schlechtes Wetter:", value: "il fait mauvais", explanation: "Es ist schlecht" },
            { label: "warm:", value: "il fait chaud", explanation: "Es ist warm" },
            { label: "kalt:", value: "il fait froid", explanation: "Es ist kalt" },
            { label: "es regnet:", value: "il pleut", explanation: "von pleuvoir" },
            { label: "es schneit:", value: "il neige", explanation: "von neiger" }
          ],
          examples: "Beispiele: Il fait beau aujourd'hui, Il pleut beaucoup en automne",
          rules: [
            "Unpersönliche Verben: il fait, il pleut, il neige",
            "Jahreszeiten mit en: en été, en automne, en hiver",
            "Ausnahme: au printemps (im Frühling)"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie sagt man 'Es regnet'?",
        sentence: "Heute regnet es. = Aujourd'hui, ___.",
        options: ["il fait pluie", "il pleut", "il a pluie"],
        correct: 1,
        explanation: "il pleut ist die korrekte unpersönliche Form."
      },
      fillInBlanks: {
        questions: [
          { sentence: "En été, ___ chaud.", answer: "il fait" },
          { sentence: "En hiver, ___ souvent.", answer: "il neige" },
          { sentence: "___ printemps, il fait beau.", answer: "Au" }
        ]
      },
      dragDrop: {
        articles: ["il fait beau", "il pleut", "il fait froid", "il neige"],
        words: [
          { word: "schönes Wetter", correct: "il fait beau" },
          { word: "es regnet", correct: "il pleut" },
          { word: "es ist kalt", correct: "il fait froid" }
        ]
      },
      matching: {
        articles: ["en été", "en hiver", "au printemps"],
        words: [
          { word: "im Sommer", translation: "", correct: "en été" },
          { word: "im Winter", translation: "", correct: "en hiver" },
          { word: "im Frühling", translation: "", correct: "au printemps" }
        ]
      }
    }
  },
  {
    id: "school-subjects",
    title: "Schulfächer und Bildung",
    subtitle: "Les matières scolaires et l'éducation",
    description: "Schulfächer und Bildungssystem in Frankreich",
    icon: "fas fa-graduation-cap",
    iconColor: "text-indigo-600",
    bgColor: "bg-indigo-100",
    level: "anfaenger",
    keywords: ["schule", "fächer", "école", "matières", "éducation"],
    explanation: {
      title: "Schulfächer und Bildung",
      introduction: "Das französische Bildungssystem hat eigene Begriffe für Schulfächer und Schularten. Viele Schulfächer sind internationale Begriffe, aber es gibt auch typisch französische Bezeichnungen.",
      content: [
        {
          title: "Die wichtigsten Schulfächer",
          description: "Schulfächer im französischen System",
          items: [
            { label: "Mathematik:", value: "les mathématiques (les maths)", explanation: "immer Plural" },
            { label: "Französisch:", value: "le français", explanation: "die Muttersprache" },
            { label: "Englisch:", value: "l'anglais", explanation: "erste Fremdsprache" },
            { label: "Geschichte:", value: "l'histoire", explanation: "weiblich: l'histoire" },
            { label: "Sport:", value: "l'EPS (éducation physique)", explanation: "sport scolaire" },
            { label: "Naturwissenschaften:", value: "les sciences", explanation: "Plural: la physique, la chimie" }
          ],
          examples: "Beispiele: J'aime les maths, Il déteste l'histoire, Nous avons anglais",
          rules: [
            "Schulfächer meist mit Artikel",
            "Präposition für 'in': avoir + Fach",
            "être fort en... = gut sein in..."
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie sagt man 'Ich habe Mathe'?",
        sentence: "Morgen habe ich Mathe.",
        options: ["J'ai les maths", "J'ai des maths", "J'ai maths"],
        correct: 0,
        explanation: "J'ai les maths - mit bestimmtem Artikel."
      },
      fillInBlanks: {
        questions: [
          { sentence: "J'aime ___ histoire.", answer: "l'" },
          { sentence: "Il est fort en ___.", answer: "maths" },
          { sentence: "Nous avons ___ aujourd'hui.", answer: "anglais" }
        ]
      },
      dragDrop: {
        articles: ["les maths", "l'histoire", "l'anglais", "l'EPS"],
        words: [
          { word: "Mathematik", correct: "les maths" },
          { word: "Geschichte", correct: "l'histoire" },
          { word: "Sport", correct: "l'EPS" }
        ]
      },
      matching: {
        articles: ["les maths", "le français", "l'anglais"],
        words: [
          { word: "Mathematik", translation: "", correct: "les maths" },
          { word: "Französisch", translation: "", correct: "le français" },
          { word: "Englisch", translation: "", correct: "l'anglais" }
        ]
      }
    }
  },
  {
    id: "food-beverages",
    title: "Essen und Trinken",
    subtitle: "La nourriture et les boissons", 
    description: "Lebensmittel, Getränke und Mahlzeiten",
    icon: "fas fa-utensils",
    iconColor: "text-orange-600",
    bgColor: "bg-orange-100",
    level: "anfaenger",
    keywords: ["essen", "trinken", "nourriture", "boissons", "restaurant"],
    explanation: {
      title: "Essen und Trinken im Französischen",
      introduction: "Essen und Trinken sind zentrale Themen der französischen Kultur. Es gibt viele spezielle Ausdrücke für Mahlzeiten, Getränke und kulinarische Begriffe, die man im Alltag benötigt.",
      content: [
        {
          title: "Grundlegende Nahrungsmittel",
          description: "Die wichtigsten Lebensmittel und Getränke",
          items: [
            { label: "Brot:", value: "le pain", explanation: "das wichtigste Grundnahrungsmittel" },
            { label: "Wasser:", value: "l'eau", explanation: "weiblich, aber l'eau" },
            { label: "Fleisch:", value: "la viande", explanation: "le bœuf, le porc, l'agneau" },
            { label: "Fisch:", value: "le poisson", explanation: "la truite, le saumon" },
            { label: "Gemüse:", value: "les légumes", explanation: "immer Plural" },
            { label: "Obst:", value: "les fruits", explanation: "la pomme, la poire, l'orange" }
          ],
          examples: "Beispiele: Je mange du pain, Elle boit de l'eau, Nous achetons des légumes",
          rules: [
            "Teilungsartikel bei Lebensmitteln: du, de la, de l', des",
            "Restaurant: Je voudrais..., L'addition, s'il vous plaît",
            "Mahlzeiten: le petit-déjeuner, le déjeuner, le dîner"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welcher Artikel passt?",
        sentence: "Je mange ___ pain.",
        options: ["le", "du", "de la"],
        correct: 1,
        explanation: "du pain - Teilungsartikel für unbestimmte Menge."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Elle boit ___ eau.", answer: "de l'" },
          { sentence: "Nous mangeons ___ viande.", answer: "de la" },
          { sentence: "Il achète ___ fruits.", answer: "des" }
        ]
      },
      dragDrop: {
        articles: ["le pain", "l'eau", "la viande", "les légumes"],
        words: [
          { word: "Brot", correct: "le pain" },
          { word: "Wasser", correct: "l'eau" },
          { word: "Gemüse", correct: "les légumes" }
        ]
      },
      matching: {
        articles: ["le petit-déjeuner", "le déjeuner", "le dîner"],
        words: [
          { word: "Frühstück", translation: "", correct: "le petit-déjeuner" },
          { word: "Mittagessen", translation: "", correct: "le déjeuner" },
          { word: "Abendessen", translation: "", correct: "le dîner" }
        ]
      }
    }
  },
  {
    id: "time-clock",
    title: "Uhrzeit und Zeit",
    subtitle: "L'heure et le temps",
    description: "Uhrzeit angeben und Zeitausdrücke verwenden",
    icon: "fas fa-clock",
    iconColor: "text-purple-600",
    bgColor: "bg-purple-100",
    level: "anfaenger",
    keywords: ["uhrzeit", "zeit", "heure", "temps", "horloge"],
    explanation: {
      title: "Uhrzeit und Zeit im Französischen",
      introduction: "Die Uhrzeit zu sagen ist essentiell für den Alltag. Im Französischen gibt es besondere Ausdrücke für Uhrzeiten und verschiedene Arten, die Zeit anzugeben.",
      content: [
        {
          title: "Uhrzeit angeben",
          description: "Wie man die Uhrzeit auf Französisch sagt",
          items: [
            { label: "Wie spät ist es?:", value: "Quelle heure est-il?", explanation: "die Standardfrage" },
            { label: "Es ist ... Uhr:", value: "Il est ... heure(s)", explanation: "il est une heure, il est deux heures" },
            { label: "Viertel nach:", value: "et quart", explanation: "il est trois heures et quart" },
            { label: "Halb:", value: "et demie", explanation: "il est quatre heures et demie" },
            { label: "Viertel vor:", value: "moins le quart", explanation: "il est cinq heures moins le quart" },
            { label: "Mittag/Mitternacht:", value: "midi/minuit", explanation: "il est midi, il est minuit" }
          ],
          examples: "Beispiele: Il est huit heures, Il est trois heures et demie, Il est minuit",
          rules: [
            "'heure' bleibt im Singular bei 'une heure'",
            "'et demie' nach Stunden, 'et demi' nach 'midi/minuit'",
            "24-Stunden-Format: Il est quinze heures (15:00)"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie sagt man 'Es ist halb drei'?",
        sentence: "Es ist 14:30.",
        options: ["Il est trois heures et demi", "Il est deux heures et demie", "Il est trois heures moins trente"],
        correct: 1,
        explanation: "Il est deux heures et demie (14:30 = halb drei nachmittags)."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il est une ___.", answer: "heure" },
          { sentence: "Il est quatre heures et ___.", answer: "demie" },
          { sentence: "Il est ___ heures moins le quart.", answer: "trois" }
        ]
      },
      dragDrop: {
        articles: ["une heure", "et quart", "et demie", "moins le quart"],
        words: [
          { word: "1:00", correct: "une heure" },
          { word: "2:15", correct: "et quart" },
          { word: "3:30", correct: "et demie" }
        ]
      },
      matching: {
        articles: ["Il est midi", "Il est minuit", "Quelle heure est-il?"],
        words: [
          { word: "Es ist Mittag", translation: "", correct: "Il est midi" },
          { word: "Es ist Mitternacht", translation: "", correct: "Il est minuit" },
          { word: "Wie spät ist es?", translation: "", correct: "Quelle heure est-il?" }
        ]
      }
    }
  },
  {
    id: "body-health",
    title: "Körper und Gesundheit",
    subtitle: "Le corps et la santé",
    description: "Körperteile und Gesundheit beschreiben",
    icon: "fas fa-heartbeat",
    iconColor: "text-red-600",
    bgColor: "bg-red-100",
    level: "anfaenger",
    keywords: ["körper", "gesundheit", "corps", "santé", "médecin"],
    explanation: {
      title: "Körper und Gesundheit",
      introduction: "Körperteile und Gesundheit sind wichtige Themen für den Alltag und besonders beim Arztbesuch. Viele Körperteile haben im Französischen ein anderes Geschlecht als im Deutschen.",
      content: [
        {
          title: "Die wichtigsten Körperteile",
          description: "Grundvokabular für den menschlichen Körper",
          items: [
            { label: "Kopf:", value: "la tête", explanation: "weiblich" },
            { label: "Auge/Augen:", value: "l'œil/les yeux", explanation: "unregelmäßiger Plural" },
            { label: "Hand:", value: "la main", explanation: "weiblich" },
            { label: "Fuß:", value: "le pied", explanation: "männlich" },
            { label: "Herz:", value: "le cœur", explanation: "männlich" },
            { label: "Mund:", value: "la bouche", explanation: "weiblich" }
          ],
          examples: "Beispiele: J'ai mal à la tête, Elle se lave les mains, Il a les yeux bleus",
          rules: [
            "'avoir mal à' + Körperteil = Schmerzen haben",
            "Artikel bei Körperteilen oft bestimmt statt possessiv",
            "Beim Arzt: Je suis malade, J'ai de la fièvre"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie sagt man 'Ich habe Kopfschmerzen'?",
        sentence: "Ich habe Kopfschmerzen.",
        options: ["J'ai mal au tête", "J'ai mal à la tête", "J'ai mal de la tête"],
        correct: 1,
        explanation: "J'ai mal à la tête - mit à + bestimmtem Artikel."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Elle a mal ___ dos.", answer: "au" },
          { sentence: "Il se lave ___ mains.", answer: "les" },
          { sentence: "Tu as ___ yeux bleus.", answer: "les" }
        ]
      },
      dragDrop: {
        articles: ["la tête", "les yeux", "la main", "le pied"],
        words: [
          { word: "Kopf", correct: "la tête" },
          { word: "Augen", correct: "les yeux" },
          { word: "Hand", correct: "la main" }
        ]
      },
      matching: {
        articles: ["J'ai mal à la tête", "J'ai de la fièvre", "Je suis malade"],
        words: [
          { word: "Ich habe Kopfschmerzen", translation: "", correct: "J'ai mal à la tête" },
          { word: "Ich habe Fieber", translation: "", correct: "J'ai de la fièvre" },
          { word: "Ich bin krank", translation: "", correct: "Je suis malade" }
        ]
      }
    }
  },
  {
    id: "transportation",
    title: "Verkehrsmittel",
    subtitle: "Les moyens de transport",
    description: "Verkehrsmittel und Reisen",
    icon: "fas fa-car",
    iconColor: "text-blue-600",
    bgColor: "bg-blue-100",
    level: "anfaenger",
    keywords: ["verkehr", "transport", "auto", "zug", "bus"],
    explanation: {
      title: "Verkehrsmittel im Französischen",
      introduction: "Verkehrsmittel sind wichtig für Reisen und den Alltag. Im Französischen gibt es verschiedene Präpositionen je nach Verkehrsmittel: en, à, par.",
      content: [
        {
          title: "Die wichtigsten Verkehrsmittel",
          description: "Transportmittel und ihre Verwendung",
          items: [
            { label: "Auto:", value: "la voiture", explanation: "en voiture" },
            { label: "Zug:", value: "le train", explanation: "en train, par le train" },
            { label: "Bus:", value: "le bus", explanation: "en bus, prendre le bus" },
            { label: "Flugzeug:", value: "l'avion", explanation: "en avion, prendre l'avion" },
            { label: "Fahrrad:", value: "le vélo", explanation: "à vélo, faire du vélo" },
            { label: "zu Fuß:", value: "à pied", explanation: "aller à pied, marcher" }
          ],
          examples: "Beispiele: Je vais en voiture, Il prend le train, Nous marchons à pied",
          rules: [
            "en + Verkehrsmittel (geschlossen): en voiture, en train",
            "à + Verkehrsmittel (offen): à vélo, à pied",
            "prendre + Verkehrsmittel = nehmen, fahren mit"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welche Präposition ist richtig?",
        sentence: "Je vais au travail ___ vélo.",
        options: ["en", "à", "par"],
        correct: 1,
        explanation: "à vélo - bei offenen Verkehrsmitteln verwendet man à."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il va ___ voiture.", answer: "en" },
          { sentence: "Elle prend ___ train.", answer: "le" },
          { sentence: "Nous allons ___ pied.", answer: "à" }
        ]
      },
      dragDrop: {
        articles: ["en voiture", "en train", "à vélo", "à pied"],
        words: [
          { word: "mit dem Auto", correct: "en voiture" },
          { word: "mit dem Zug", correct: "en train" },
          { word: "mit dem Fahrrad", correct: "à vélo" }
        ]
      },
      matching: {
        articles: ["prendre le bus", "aller en avion", "marcher à pied"],
        words: [
          { word: "Bus fahren", translation: "", correct: "prendre le bus" },
          { word: "fliegen", translation: "", correct: "aller en avion" },
          { word: "zu Fuß gehen", translation: "", correct: "marcher à pied" }
        ]
      }
    }
  },
  {
    id: "clothing-fashion",
    title: "Kleidung und Mode",
    subtitle: "Les vêtements et la mode",
    description: "Kleidungsstücke und Modeausdrücke",
    icon: "fas fa-tshirt",
    iconColor: "text-purple-600",
    bgColor: "bg-purple-100",
    level: "anfaenger",
    keywords: ["kleidung", "mode", "vêtements", "porter", "habits"],
    explanation: {
      title: "Kleidung und Mode im Französischen",
      introduction: "Kleidung zu beschreiben ist ein wichtiger Teil des täglichen Wortschatzes. Franzosen legen viel Wert auf Mode und Stil, daher gibt es viele spezifische Begriffe für Kleidungsstücke.",
      content: [
        {
          title: "Grundlegende Kleidungsstücke",
          description: "Die wichtigsten Kleidungsstücke und ihre Verwendung",
          items: [
            { label: "T-Shirt:", value: "le tee-shirt", explanation: "männlich" },
            { label: "Hose:", value: "le pantalon", explanation: "immer Singular" },
            { label: "Kleid:", value: "la robe", explanation: "weiblich" },
            { label: "Schuhe:", value: "les chaussures", explanation: "immer Plural" },
            { label: "Jacke:", value: "la veste", explanation: "weiblich" },
            { label: "Pullover:", value: "le pull", explanation: "männlich" }
          ],
          examples: "Beispiele: Je porte un jean, Elle met une robe, Il achète des chaussures",
          rules: [
            "porter = tragen, anziehen",
            "mettre = anziehen (Vorgang)",
            "Farben nach Kleidungsstück: une robe rouge"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welcher Artikel ist richtig?",
        sentence: "Elle porte ___ belle robe.",
        options: ["un", "une", "des"],
        correct: 1,
        explanation: "une robe - robe ist weiblich."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il met ___ pantalon noir.", answer: "un" },
          { sentence: "Elle achète ___ chaussures.", answer: "des" },
          { sentence: "Tu portes ___ pull rouge.", answer: "un" }
        ]
      },
      dragDrop: {
        articles: ["le tee-shirt", "la robe", "les chaussures", "le pantalon"],
        words: [
          { word: "T-Shirt", correct: "le tee-shirt" },
          { word: "Kleid", correct: "la robe" },
          { word: "Schuhe", correct: "les chaussures" }
        ]
      },
      matching: {
        articles: ["Je porte", "Elle met", "Il achète"],
        words: [
          { word: "Ich trage", translation: "", correct: "Je porte" },
          { word: "Sie zieht an", translation: "", correct: "Elle met" },
          { word: "Er kauft", translation: "", correct: "Il achète" }
        ]
      }
    }
  },
  {
    id: "house-home",
    title: "Haus und Wohnung",
    subtitle: "La maison et l'appartement",
    description: "Räume, Möbel und Wohnbereiche",
    icon: "fas fa-home",
    iconColor: "text-green-600",
    bgColor: "bg-green-100",
    level: "anfaenger",
    keywords: ["haus", "wohnung", "maison", "appartement", "pièce"],
    explanation: {
      title: "Haus und Wohnung im Französischen",
      introduction: "Das Zuhause zu beschreiben ist ein wichtiger Teil des täglichen Wortschatzes. Französische Häuser haben oft eine andere Struktur als deutsche, daher gibt es spezifische Begriffe.",
      content: [
        {
          title: "Räume und Bereiche",
          description: "Die wichtigsten Räume im Haus",
          items: [
            { label: "Küche:", value: "la cuisine", explanation: "weiblich" },
            { label: "Wohnzimmer:", value: "le salon", explanation: "auch: le séjour" },
            { label: "Schlafzimmer:", value: "la chambre", explanation: "la chambre à coucher" },
            { label: "Badezimmer:", value: "la salle de bains", explanation: "mit 's' am Ende" },
            { label: "WC:", value: "les toilettes", explanation: "immer Plural" },
            { label: "Garten:", value: "le jardin", explanation: "männlich" }
          ],
          examples: "Beispiele: Ma chambre est grande, La cuisine est moderne, Le jardin est beau",
          rules: [
            "dans + Raum = in dem Raum",
            "chez moi = bei mir zu Hause",
            "habiter + Präposition = wohnen"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welcher Artikel ist richtig?",
        sentence: "Je suis dans ___ cuisine.",
        options: ["le", "la", "les"],
        correct: 1,
        explanation: "la cuisine - cuisine ist weiblich."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Ma ___ est petite.", answer: "chambre" },
          { sentence: "Le ___ est grand.", answer: "salon" },
          { sentence: "Il est dans ___ jardin.", answer: "le" }
        ]
      },
      dragDrop: {
        articles: ["la cuisine", "le salon", "la chambre", "le jardin"],
        words: [
          { word: "Küche", correct: "la cuisine" },
          { word: "Wohnzimmer", correct: "le salon" },
          { word: "Schlafzimmer", correct: "la chambre" }
        ]
      },
      matching: {
        articles: ["dans la cuisine", "chez moi", "au jardin"],
        words: [
          { word: "in der Küche", translation: "", correct: "dans la cuisine" },
          { word: "bei mir zu Hause", translation: "", correct: "chez moi" },
          { word: "im Garten", translation: "", correct: "au jardin" }
        ]
      }
    }
  },
  {
    id: "hobbies-leisure",
    title: "Hobbys und Freizeit",
    subtitle: "Les loisirs et les passe-temps",
    description: "Freizeitaktivitäten und Hobbys beschreiben",
    icon: "fas fa-gamepad",
    iconColor: "text-blue-600",
    bgColor: "bg-blue-100",
    level: "anfaenger",
    keywords: ["hobbys", "freizeit", "loisirs", "sport", "musique"],
    explanation: {
      title: "Hobbys und Freizeit im Französischen",
      introduction: "Freizeitaktivitäten zu beschreiben ist wichtig für Gespräche und das Kennenlernen. Im Französischen gibt es verschiedene Verben für verschiedene Aktivitäten.",
      content: [
        {
          title: "Beliebte Freizeitaktivitäten",
          description: "Die wichtigsten Hobbys und Aktivitäten",
          items: [
            { label: "Sport treiben:", value: "faire du sport", explanation: "faire du foot, du tennis" },
            { label: "Musik hören:", value: "écouter de la musique", explanation: "mit Teilungsartikel" },
            { label: "lesen:", value: "lire", explanation: "lire un livre, un journal" },
            { label: "fernsehen:", value: "regarder la télé", explanation: "regarder la télévision" },
            { label: "Spiele spielen:", value: "jouer aux jeux", explanation: "jouer aux jeux vidéo" },
            { label: "Musik machen:", value: "jouer de la musique", explanation: "jouer du piano, de la guitare" }
          ],
          examples: "Beispiele: Je fais du sport, Elle écoute de la musique, Il joue au tennis",
          rules: [
            "faire du/de la = (Sport) machen",
            "jouer au/aux = (Spiel) spielen",
            "jouer du/de la = (Instrument) spielen"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welche Präposition ist richtig?",
        sentence: "Il joue ___ piano.",
        options: ["au", "du", "de la"],
        correct: 1,
        explanation: "jouer du piano - bei Instrumenten: jouer du/de la."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Je fais ___ sport.", answer: "du" },
          { sentence: "Elle joue ___ tennis.", answer: "au" },
          { sentence: "Il écoute ___ musique.", answer: "de la" }
        ]
      },
      dragDrop: {
        articles: ["faire du sport", "jouer au tennis", "lire un livre", "écouter la musique"],
        words: [
          { word: "Sport treiben", correct: "faire du sport" },
          { word: "Tennis spielen", correct: "jouer au tennis" },
          { word: "ein Buch lesen", correct: "lire un livre" }
        ]
      },
      matching: {
        articles: ["Mon hobby", "Je fais", "J'aime"],
        words: [
          { word: "Mein Hobby", translation: "", correct: "Mon hobby" },
          { word: "Ich mache", translation: "", correct: "Je fais" },
          { word: "Ich mag", translation: "", correct: "J'aime" }
        ]
      }
    }
  },
  {
    id: "animals-nature",
    title: "Tiere und Natur",
    subtitle: "Les animaux et la nature",
    description: "Tiere, Pflanzen und Natur beschreiben",
    icon: "fas fa-paw",
    iconColor: "text-green-600",
    bgColor: "bg-green-100",
    level: "anfaenger",
    keywords: ["tiere", "natur", "animaux", "nature", "forêt"],
    explanation: {
      title: "Tiere und Natur im Französischen",
      introduction: "Tiere und Natur sind beliebte Gesprächsthemen und wichtig für Beschreibungen. Viele Tiernamen haben im Französischen ein anderes Geschlecht als im Deutschen.",
      content: [
        {
          title: "Haustiere und wilde Tiere",
          description: "Die wichtigsten Tiere und Naturelemente",
          items: [
            { label: "Hund:", value: "le chien", explanation: "männlich" },
            { label: "Katze:", value: "le chat", explanation: "männlich (la chatte für weiblich)" },
            { label: "Vogel:", value: "l'oiseau", explanation: "männlich" },
            { label: "Pferd:", value: "le cheval", explanation: "Plural: les chevaux" },
            { label: "Baum:", value: "l'arbre", explanation: "männlich" },
            { label: "Blume:", value: "la fleur", explanation: "weiblich" }
          ],
          examples: "Beispiele: J'ai un chien, Les oiseaux chantent, Les fleurs sont belles",
          rules: [
            "avoir un animal = ein Tier haben",
            "Tierlaute: Le chien aboie, Le chat miaule",
            "In der Natur: dans la forêt, au parc"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welcher Artikel ist richtig?",
        sentence: "J'aime ___ chats.",
        options: ["le", "la", "les"],
        correct: 2,
        explanation: "les chats - Plural von le chat."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Mon ___ est mignon.", answer: "chien" },
          { sentence: "Les ___ chantent.", answer: "oiseaux" },
          { sentence: "Cette ___ est belle.", answer: "fleur" }
        ]
      },
      dragDrop: {
        articles: ["le chien", "le chat", "l'oiseau", "la fleur"],
        words: [
          { word: "Hund", correct: "le chien" },
          { word: "Katze", correct: "le chat" },
          { word: "Vogel", correct: "l'oiseau" }
        ]
      },
      matching: {
        articles: ["dans la forêt", "au parc", "mon animal"],
        words: [
          { word: "im Wald", translation: "", correct: "dans la forêt" },
          { word: "im Park", translation: "", correct: "au parc" },
          { word: "mein Tier", translation: "", correct: "mon animal" }
        ]
      }
    }
  },
  {
    id: "past-participle",
    title: "Partizip Perfekt",
    subtitle: "Le participe passé - Angleichung",
    description: "Bildung und Angleichung des Partizip Perfekts",
    icon: "fas fa-check-circle",
    iconColor: "text-green-600",
    bgColor: "bg-green-100",
    level: "fortgeschritten",
    keywords: ["partizip", "perfekt", "participe", "passé", "accord"],
    explanation: {
      title: "Das Partizip Perfekt und seine Angleichung",
      introduction: "Das Partizip Perfekt wird zur Bildung zusammengesetzter Zeiten verwendet. Es kann sich an das Subjekt oder das direkte Objekt angleichen, je nach Hilfsverb und Satzstellung.",
      content: [
        {
          title: "Angleichungsregeln",
          description: "Wann und wie das Partizip angeglichen wird",
          items: [
            { label: "mit être:", value: "immer Angleichung", explanation: "Elle est partie, Ils sont venus" },
            { label: "mit avoir:", value: "nur bei vorangestelltem COD", explanation: "La pomme qu'il a mangée" },
            { label: "reflexive Verben:", value: "meist Angleichung", explanation: "Elle s'est lavée" },
            { label: "keine Angleichung:", value: "bei nachgestelltem COD", explanation: "Il a mangé une pomme" }
          ],
          examples: "Beispiele: Elles sont arrivées, Les livres qu'elle a lus, Il s'est lavé",
          rules: [
            "Weiblich: +e, Plural: +s, weiblich Plural: +es",
            "Bei stummen Endungen ändert sich die Aussprache nicht",
            "Besondere Fälle bei reflexiven Verben beachten"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welche Form ist richtig?",
        sentence: "Les filles sont _____.",
        options: ["parti", "partie", "parties"],
        correct: 2,
        explanation: "parties - weiblich Plural mit être."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Elle est _____. (venir)", answer: "venue" },
          { sentence: "Ils ont _____ le livre. (lire)", answer: "lu" },
          { sentence: "Elles se sont _____. (laver)", answer: "lavées" }
        ]
      },
      dragDrop: {
        articles: ["arrivée", "venus", "parties", "mangé"],
        words: [
          { word: "elle est _____ (ankommen)", correct: "arrivée" },
          { word: "ils sont _____ (kommen)", correct: "venus" },
          { word: "elles sont _____ (weggehen)", correct: "parties" }
        ]
      },
      matching: {
        articles: ["Elle est venue", "Ils ont mangé", "Elles se sont lavées"],
        words: [
          { word: "Sie ist gekommen", translation: "", correct: "Elle est venue" },
          { word: "Sie haben gegessen", translation: "", correct: "Ils ont mangé" },
          { word: "Sie haben sich gewaschen", translation: "", correct: "Elles se sont lavées" }
        ]
      }
    }
  },
  {
    id: "technology-internet",
    title: "Technologie und Internet",
    subtitle: "La technologie et l'internet",
    description: "Computer, Internet und moderne Technologie",
    icon: "fas fa-laptop",
    iconColor: "text-blue-600",
    bgColor: "bg-blue-100",
    level: "mittelstufe",
    keywords: ["technologie", "internet", "ordinateur", "portable", "wifi"],
    explanation: {
      title: "Technologie und Internet",
      introduction: "Technologie ist aus dem modernen Leben nicht wegzudenken. Im Französischen gibt es viele englische Lehnwörter, aber auch rein französische Begriffe für technische Geräte.",
      content: [
        {
          title: "Computer und Internet",
          description: "Wichtige Begriffe der digitalen Welt",
          items: [
            { label: "Computer:", value: "l'ordinateur", explanation: "männlich" },
            { label: "Handy:", value: "le portable", explanation: "auch: le téléphone portable" },
            { label: "Internet:", value: "l'internet", explanation: "männlich" },
            { label: "E-Mail:", value: "le mail/le courriel", explanation: "courriel ist offizieller" },
            { label: "Website:", value: "le site web", explanation: "auch: le site internet" },
            { label: "App:", value: "l'application", explanation: "weiblich, oft verkürzt: l'appli" }
          ],
          examples: "Beispiele: J'utilise mon ordinateur, Il envoie un mail, Elle télécharge une appli",
          rules: [
            "utiliser = benutzen, verwenden",
            "télécharger = herunterladen",
            "envoyer un mail = eine E-Mail senden"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welcher Artikel ist richtig?",
        sentence: "J'achète ___ nouvel ordinateur.",
        options: ["un", "une", "des"],
        correct: 0,
        explanation: "un ordinateur - ordinateur ist männlich."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Elle utilise ___ portable.", answer: "son" },
          { sentence: "Il télécharge ___ application.", answer: "une" },
          { sentence: "Nous naviguons sur ___.", answer: "l'internet" }
        ]
      },
      dragDrop: {
        articles: ["l'ordinateur", "le portable", "l'internet", "l'application"],
        words: [
          { word: "Computer", correct: "l'ordinateur" },
          { word: "Handy", correct: "le portable" },
          { word: "App", correct: "l'application" }
        ]
      },
      matching: {
        articles: ["envoyer un mail", "télécharger", "utiliser"],
        words: [
          { word: "E-Mail senden", translation: "", correct: "envoyer un mail" },
          { word: "herunterladen", translation: "", correct: "télécharger" },
          { word: "benutzen", translation: "", correct: "utiliser" }
        ]
      }
    }
  },
  {
    id: "emotions-feelings",
    title: "Gefühle und Emotionen",
    subtitle: "Les sentiments et les émotions",
    description: "Gefühle beschreiben und ausdrücken",
    icon: "fas fa-heart",
    iconColor: "text-pink-600",
    bgColor: "bg-pink-100",
    level: "mittelstufe",
    keywords: ["gefühle", "emotionen", "sentiments", "heureux", "triste"],
    explanation: {
      title: "Gefühle und Emotionen im Französischen",
      introduction: "Gefühle auszudrücken ist ein wichtiger Teil der zwischenmenschlichen Kommunikation. Im Französischen gibt es viele nuancierte Begriffe für verschiedene Emotionen.",
      content: [
        {
          title: "Grundlegende Gefühle",
          description: "Die wichtigsten Emotionen und ihre Ausdrucksformen",
          items: [
            { label: "glücklich:", value: "heureux/heureuse", explanation: "Je suis heureux" },
            { label: "traurig:", value: "triste", explanation: "Il est triste" },
            { label: "ärgerlich:", value: "fâché(e)", explanation: "Elle est fâchée" },
            { label: "müde:", value: "fatigué(e)", explanation: "Nous sommes fatigués" },
            { label: "ängstlich:", value: "anxieux/anxieuse", explanation: "Tu es anxieux" },
            { label: "aufgeregt:", value: "excité(e)", explanation: "Ils sont excités" }
          ],
          examples: "Beispiele: Je suis content, Elle a peur, Il est en colère",
          rules: [
            "'avoir' Ausdrücke: avoir peur, avoir honte",
            "'être' + Adjektiv: être heureux, être triste",
            "Gefühle begründen: parce que, car"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Welche Form ist richtig?",
        sentence: "Elle est très _____.",
        options: ["heureux", "heureuse", "heureus"],
        correct: 1,
        explanation: "heureuse - weibliche Form von heureux."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Je suis _____.", answer: "content" },
          { sentence: "Il a _____ du chien.", answer: "peur" },
          { sentence: "Nous sommes _____.", answer: "fatigués" }
        ]
      },
      dragDrop: {
        articles: ["heureux", "triste", "fâché", "fatigué"],
        words: [
          { word: "glücklich", correct: "heureux" },
          { word: "traurig", correct: "triste" },
          { word: "ärgerlich", correct: "fâché" }
        ]
      },
      matching: {
        articles: ["avoir peur", "être content", "avoir honte"],
        words: [
          { word: "Angst haben", translation: "", correct: "avoir peur" },
          { word: "zufrieden sein", translation: "", correct: "être content" },
          { word: "sich schämen", translation: "", correct: "avoir honte" }
        ]
      }
    }
  },
  {
    id: "professions-jobs",
    title: "Berufe und Arbeit",
    subtitle: "Les professions et le travail",
    description: "Berufe beschreiben und über Arbeit sprechen",
    icon: "fas fa-briefcase",
    iconColor: "text-gray-600",
    bgColor: "bg-gray-100",
    level: "mittelstufe",
    keywords: ["beruf", "arbeit", "profession", "travail", "métier"],
    explanation: {
      title: "Berufe und Arbeit im Französischen",
      introduction: "Berufe zu beschreiben ist wichtig für Vorstellungen und Gespräche. Viele Berufsbezeichnungen haben männliche und weibliche Formen.",
      content: [
        {
          title: "Wichtige Berufe",
          description: "Grundlegende Berufsbezeichnungen",
          items: [
            { label: "Lehrer/in:", value: "le professeur/la professeure", explanation: "auch: l'instituteur/trice" },
            { label: "Arzt/Ärztin:", value: "le médecin", explanation: "meist unverheiratet: le docteur" },
            { label: "Ingénieur/in:", value: "l'ingénieur(e)", explanation: "weiblich: l'ingénieure" },
            { label: "Verkäufer/in:", value: "le vendeur/la vendeuse", explanation: "im Laden" },
            { label: "Student/in:", value: "l'étudiant(e)", explanation: "an der Universität" },
            { label: "Koch/Köchin:", value: "le cuisinier/la cuisinière", explanation: "auch: le chef" }
          ],
          examples: "Beispiele: Il est professeur, Elle travaille comme médecin, Je suis étudiant",
          rules: [
            "Beruf ohne Artikel: Il est professeur",
            "Mit comme: Elle travaille comme...",
            "Arbeitsplatz: au bureau, à l'hôpital, à l'école"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie sagt man den Beruf?",
        sentence: "Elle est _____.",
        options: ["une professeure", "professeure", "le professeure"],
        correct: 1,
        explanation: "professeure - Beruf ohne Artikel nach être."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Il travaille comme _____.", answer: "médecin" },
          { sentence: "Je suis _____ à l'université.", answer: "étudiant" },
          { sentence: "Elle est _____ dans une école.", answer: "professeure" }
        ]
      },
      dragDrop: {
        articles: ["professeur", "médecin", "étudiant", "ingénieur"],
        words: [
          { word: "Lehrer", correct: "professeur" },
          { word: "Arzt", correct: "médecin" },
          { word: "Student", correct: "étudiant" }
        ]
      },
      matching: {
        articles: ["au bureau", "à l'hôpital", "à l'école"],
        words: [
          { word: "im Büro", translation: "", correct: "au bureau" },
          { word: "im Krankenhaus", translation: "", correct: "à l'hôpital" },
          { word: "in der Schule", translation: "", correct: "à l'école" }
        ]
      }
    }
  },
  {
    id: "shopping-money",
    title: "Einkaufen und Geld",
    subtitle: "Les achats et l'argent",
    description: "Einkaufen, Preise und Geld",
    icon: "fas fa-shopping-cart",
    iconColor: "text-green-600",
    bgColor: "bg-green-100",
    level: "mittelstufe",
    keywords: ["einkaufen", "geld", "achats", "argent", "prix"],
    explanation: {
      title: "Einkaufen und Geld",
      introduction: "Einkaufen und mit Geld umgehen sind tägliche Aktivitäten. Im Französischen gibt es spezielle Ausdrücke für Geschäfte, Preise und Zahlungen.",
      content: [
        {
          title: "Einkaufen und Preise",
          description: "Wichtige Begriffe rund ums Einkaufen",
          items: [
            { label: "kaufen:", value: "acheter", explanation: "j'achète, tu achètes" },
            { label: "verkaufen:", value: "vendre", explanation: "je vends, il vend" },
            { label: "Preis:", value: "le prix", explanation: "Ça coûte combien?" },
            { label: "Geld:", value: "l'argent", explanation: "männlich" },
            { label: "Euro:", value: "l'euro", explanation: "männlich" },
            { label: "Laden:", value: "le magasin", explanation: "auch: la boutique" }
          ],
          examples: "Beispiele: J'achète du pain, Ça coûte 5 euros, Il paye par carte",
          rules: [
            "Coûter = kosten: Ça coûte...",
            "Payer = bezahlen: payer par carte/en espèces",
            "Im Laden: Combien ça coûte? Je voudrais..."
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie fragt man nach dem Preis?",
        sentence: "Wie viel kostet das?",
        options: ["Combien coûte?", "Ça coûte combien?", "Quel est le prix combien?"],
        correct: 1,
        explanation: "Ça coûte combien? ist die häufigste Form."
      },
      fillInBlanks: {
        questions: [
          { sentence: "J'_____ du pain.", answer: "achète" },
          { sentence: "Ça _____ 10 euros.", answer: "coûte" },
          { sentence: "Il paye en _____.", answer: "espèces" }
        ]
      },
      dragDrop: {
        articles: ["acheter", "vendre", "coûter", "payer"],
        words: [
          { word: "kaufen", correct: "acheter" },
          { word: "verkaufen", correct: "vendre" },
          { word: "kosten", correct: "coûter" }
        ]
      },
      matching: {
        articles: ["par carte", "en espèces", "le magasin"],
        words: [
          { word: "mit Karte", translation: "", correct: "par carte" },
          { word: "bar", translation: "", correct: "en espèces" },
          { word: "der Laden", translation: "", correct: "le magasin" }
        ]
      }
    }
  },
  {
    id: "directions-places",
    title: "Wegbeschreibung und Orte",
    subtitle: "Les directions et les lieux",
    description: "Wege beschreiben und Orte finden",
    icon: "fas fa-map-marker-alt",
    iconColor: "text-red-600",
    bgColor: "bg-red-100",
    level: "mittelstufe",
    keywords: ["weg", "richtung", "directions", "lieux", "ville"],
    explanation: {
      title: "Wegbeschreibung und Orte",
      introduction: "Wege zu beschreiben und nach Orten zu fragen ist im Alltag sehr wichtig. Im Französischen gibt es spezielle Ausdrücke für Richtungen und Ortsangaben.",
      content: [
        {
          title: "Richtungen und Wegbeschreibung",
          description: "Wichtige Begriffe für Navigation",
          items: [
            { label: "links:", value: "à gauche", explanation: "tournez à gauche" },
            { label: "rechts:", value: "à droite", explanation: "allez à droite" },
            { label: "geradeaus:", value: "tout droit", explanation: "continuez tout droit" },
            { label: "hier:", value: "ici", explanation: "je suis ici" },
            { label: "dort:", value: "là", explanation: "c'est là" },
            { label: "Straße:", value: "la rue", explanation: "dans la rue" }
          ],
          examples: "Beispiele: Tournez à droite, C'est tout droit, Où est la banque?",
          rules: [
            "Où est...? = Wo ist...?",
            "Comment aller à...? = Wie kommt man zu...?",
            "Imperativ für Anweisungen: Tournez, Allez, Prenez"
          ]
        }
      ]
    },
    exercises: {
      multipleChoice: {
        question: "Wie sagt man 'geradeaus'?",
        sentence: "Gehen Sie geradeaus.",
        options: ["Allez à gauche", "Allez tout droit", "Tournez à droite"],
        correct: 1,
        explanation: "Allez tout droit = Gehen Sie geradeaus."
      },
      fillInBlanks: {
        questions: [
          { sentence: "Tournez à _____.", answer: "droite" },
          { sentence: "Où est la _____?", answer: "banque" },
          { sentence: "C'est _____ droit.", answer: "tout" }
        ]
      },
      dragDrop: {
        articles: ["à gauche", "à droite", "tout droit", "ici"],
        words: [
          { word: "links", correct: "à gauche" },
          { word: "rechts", correct: "à droite" },
          { word: "geradeaus", correct: "tout droit" }
        ]
      },
      matching: {
        articles: ["Où est?", "Comment aller?", "Excusez-moi"],
        words: [
          { word: "Wo ist?", translation: "", correct: "Où est?" },
          { word: "Wie kommt man?", translation: "", correct: "Comment aller?" },
          { word: "Entschuldigung", translation: "", correct: "Excusez-moi" }
        ]
      }
    }
  }
];