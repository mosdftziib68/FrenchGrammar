import { useState } from "react";
import Feedback from "@/components/ui/feedback";

interface MatchingProps {
  exercise: {
    articles: string[];
    words: Array<{
      word: string;
      translation: string;
      correct: string;
    }>;
  };
  exerciseNumber: number;
}

export default function Matching({ exercise, exerciseNumber }: MatchingProps) {
  const [selectedArticle, setSelectedArticle] = useState<string | null>(null);
  const [matches, setMatches] = useState<{ [key: string]: string }>({});
  const [isChecked, setIsChecked] = useState(false);

  const handleArticleSelect = (article: string) => {
    if (isChecked) return;
    setSelectedArticle(selectedArticle === article ? null : article);
  };

  const handleWordSelect = (wordIndex: number) => {
    if (!selectedArticle || isChecked) return;
    
    const word = exercise.words[wordIndex];
    setMatches(prev => ({ ...prev, [word.correct]: selectedArticle }));
    setSelectedArticle(null);
  };

  const checkAnswers = () => {
    setIsChecked(true);
  };

  const resetExercise = () => {
    setSelectedArticle(null);
    setMatches({});
    setIsChecked(false);
  };

  const correctMatches = exercise.words.filter(word =>
    matches[word.correct] === word.correct
  ).length;

  const getWordDisplay = (word: any, index: number) => {
    const userMatch = matches[word.correct];
    if (isChecked) {
      if (userMatch === word.correct) {
        return `${word.word} ${word.translation ? `(${word.translation})` : ''}`;
      } else if (userMatch) {
        return `${word.word} ${word.translation ? `(${word.translation})` : ''} → ${word.correct}`;
      }
    }
    return `${word.word} ${word.translation ? `(${word.translation})` : ''}${userMatch ? ` → ${userMatch}` : ''}`;
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-foreground">
          <i className="fas fa-link text-pink-500 mr-2"></i>
          Übung {exerciseNumber}: Zuordnung
        </h3>
        {isChecked && (
          <button
            onClick={resetExercise}
            className="text-sm text-muted-foreground hover:text-primary"
            data-testid="button-reset-matching"
          >
            <i className="fas fa-redo mr-1"></i>
            Wiederholen
          </button>
        )}
      </div>
      
      <div className="mb-6">
        <p className="text-foreground mb-4">Ordne die Artikel den Wörtern zu:</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Articles Column */}
          <div>
            <h4 className="font-medium mb-3">Artikel:</h4>
            <div className="space-y-2">
              {exercise.articles.map((article, index) => (
                <button
                  key={index}
                  onClick={() => handleArticleSelect(article)}
                  className={`matching-item w-full p-3 rounded-lg text-left transition-all ${
                    selectedArticle === article
                      ? 'bg-primary text-primary-foreground ring-2 ring-ring'
                      : 'bg-primary text-primary-foreground hover:bg-primary/90'
                  }`}
                  data-testid={`article-${article}`}
                >
                  {article}
                </button>
              ))}
            </div>
          </div>
          
          {/* Words Column */}
          <div>
            <h4 className="font-medium mb-3">Wörter:</h4>
            <div className="space-y-2">
              {exercise.words.map((word, index) => {
                const userMatch = matches[word.correct];
                const isCorrect = isChecked && userMatch === word.correct;
                const isIncorrect = isChecked && userMatch && userMatch !== word.correct;
                
                return (
                  <button
                    key={index}
                    onClick={() => handleWordSelect(index)}
                    className={`matching-target w-full p-3 rounded-lg text-left border-2 transition-all ${
                      isCorrect
                        ? 'bg-green-100 border-green-500'
                        : isIncorrect
                          ? 'bg-red-100 border-red-500'
                          : userMatch
                            ? 'bg-muted border-muted-foreground'
                            : 'bg-secondary border-transparent hover:border-primary'
                    }`}
                    data-testid={`word-${index}`}
                  >
                    {getWordDisplay(word, index)}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
        
        {!isChecked && (
          <button
            onClick={checkAnswers}
            className="mt-6 bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
            data-testid="button-check-matching"
          >
            Überprüfen
          </button>
        )}

        {isChecked && (
          <Feedback
            isCorrect={correctMatches === exercise.words.length}
            message={
              correctMatches === exercise.words.length
                ? `✅ Fantastisch! Alle Zuordnungen sind korrekt!`
                : `⚠️ ${correctMatches}/${exercise.words.length} richtig. Die korrekten Zuordnungen werden angezeigt.`
            }
          />
        )}
      </div>
    </div>
  );
}
