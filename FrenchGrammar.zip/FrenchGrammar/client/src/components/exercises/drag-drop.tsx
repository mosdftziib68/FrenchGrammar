import { useState, useEffect } from "react";
import Feedback from "@/components/ui/feedback";

interface DragDropProps {
  exercise: {
    articles: string[];
    words: Array<{
      word: string;
      correct: string;
    }>;
  };
  exerciseNumber: number;
}

export default function DragDrop({ exercise, exerciseNumber }: DragDropProps) {
  const [droppedItems, setDroppedItems] = useState<{ [key: number]: string }>({});
  const [isChecked, setIsChecked] = useState(false);
  const [draggedItem, setDraggedItem] = useState<string | null>(null);

  const handleDragStart = (e: React.DragEvent, article: string) => {
    setDraggedItem(article);
    e.dataTransfer.setData('text/plain', article);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, wordIndex: number) => {
    e.preventDefault();
    if (isChecked) return;
    
    const article = e.dataTransfer.getData('text/plain');
    setDroppedItems(prev => ({ ...prev, [wordIndex]: article }));
    setDraggedItem(null);
  };

  const checkAnswers = () => {
    setIsChecked(true);
  };

  const resetExercise = () => {
    setDroppedItems({});
    setIsChecked(false);
  };

  const correctAnswers = exercise.words.filter((word, index) =>
    droppedItems[index] === word.correct
  ).length;

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-foreground">
          <i className="fas fa-arrows-alt text-blue-500 mr-2"></i>
          Übung {exerciseNumber}: Drag & Drop
        </h3>
        {isChecked && (
          <button
            onClick={resetExercise}
            className="text-sm text-muted-foreground hover:text-primary"
            data-testid="button-reset-drag-drop"
          >
            <i className="fas fa-redo mr-1"></i>
            Wiederholen
          </button>
        )}
      </div>
      
      <div className="mb-6">
        <p className="text-foreground mb-4">Ziehe die richtigen Artikel zu den Wörtern:</p>
        
        {/* Draggable Articles */}
        <div className="mb-6">
          <p className="text-sm text-muted-foreground mb-2">Artikel:</p>
          <div className="flex flex-wrap gap-3">
            {exercise.articles.map((article, index) => (
              <div
                key={index}
                draggable={!isChecked}
                onDragStart={(e) => handleDragStart(e, article)}
                className={`draggable px-4 py-2 rounded-lg cursor-grab transition-opacity ${
                  article.startsWith('un') || article === 'des'
                    ? 'bg-accent text-accent-foreground'
                    : 'bg-primary text-primary-foreground'
                } ${Object.values(droppedItems).includes(article) ? 'opacity-50' : ''}`}
                data-testid={`draggable-${article}`}
              >
                {article}
              </div>
            ))}
          </div>
        </div>

        {/* Drop Zones */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {exercise.words.map((word, index) => {
            const droppedArticle = droppedItems[index];
            const isCorrect = isChecked && droppedArticle === word.correct;
            const isIncorrect = isChecked && droppedArticle && droppedArticle !== word.correct;
            
            return (
              <div key={index} className="bg-secondary rounded-lg p-4">
                <div
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDrop(e, index)}
                  className={`drag-zone rounded-lg p-3 mb-2 flex items-center justify-center text-muted-foreground min-h-[60px] ${
                    isCorrect
                      ? 'bg-green-100 border-green-500'
                      : isIncorrect
                        ? 'bg-red-100 border-red-500'
                        : droppedArticle
                          ? 'bg-muted font-semibold text-foreground'
                          : ''
                  }`}
                  data-testid={`drop-zone-${index}`}
                >
                  {droppedArticle || 'Artikel hier ablegen'}
                  {isIncorrect && ` → ${word.correct}`}
                </div>
                <p className="text-center font-medium">{word.word}</p>
              </div>
            );
          })}
        </div>
        
        {!isChecked && (
          <button
            onClick={checkAnswers}
            className="mt-4 bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
            data-testid="button-check-drag-drop"
          >
            Überprüfen
          </button>
        )}

        {isChecked && (
          <Feedback
            isCorrect={correctAnswers === exercise.words.length}
            message={
              correctAnswers === exercise.words.length
                ? `✅ Ausgezeichnet! Alle Zuordnungen sind richtig!`
                : `⚠️ ${correctAnswers}/${exercise.words.length} richtig. Die korrekten Antworten werden angezeigt.`
            }
          />
        )}
      </div>
    </div>
  );
}
