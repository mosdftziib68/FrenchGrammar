import { useState } from "react";
import Feedback from "@/components/ui/feedback";

interface MultipleChoiceProps {
  exercise: {
    question: string;
    sentence: string;
    options: string[];
    correct: number;
    explanation: string;
  };
  exerciseNumber: number;
}

export default function MultipleChoice({ exercise, exerciseNumber }: MultipleChoiceProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const handleAnswer = (optionIndex: number) => {
    if (selectedAnswer !== null) return; // Already answered
    
    setSelectedAnswer(optionIndex);
    setShowFeedback(true);
  };

  const resetExercise = () => {
    setSelectedAnswer(null);
    setShowFeedback(false);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-foreground">
          <i className="fas fa-check-circle text-primary mr-2"></i>
          Übung {exerciseNumber}: Multiple Choice
        </h3>
        {showFeedback && (
          <button
            onClick={resetExercise}
            className="text-sm text-muted-foreground hover:text-primary"
            data-testid="button-reset-multiple-choice"
          >
            <i className="fas fa-redo mr-1"></i>
            Wiederholen
          </button>
        )}
      </div>
      
      <div className="mb-6">
        <p className="text-foreground mb-4">{exercise.question}</p>
        <div className="bg-secondary rounded-lg p-4 mb-4">
          <p className="text-lg">
            <span className="font-semibold">{exercise.sentence}</span>
          </p>
        </div>
        
        <div className="grid grid-cols-3 gap-4">
          {exercise.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(index)}
              disabled={selectedAnswer !== null}
              className={`exercise-option p-3 rounded-lg border transition-colors ${
                selectedAnswer === null
                  ? 'bg-background border-border hover:border-primary'
                  : selectedAnswer === index
                    ? index === exercise.correct
                      ? 'correct'
                      : 'incorrect'
                    : index === exercise.correct
                      ? 'correct'
                      : 'bg-background border-border'
              }`}
              data-testid={`option-${index}`}
            >
              {option}
            </button>
          ))}
        </div>

        {showFeedback && (
          <Feedback
            isCorrect={selectedAnswer === exercise.correct}
            message={
              selectedAnswer === exercise.correct
                ? `✅ Richtig! ${exercise.explanation}`
                : `❌ Falsch! Die richtige Antwort ist "${exercise.options[exercise.correct]}". ${exercise.explanation}`
            }
          />
        )}
      </div>
    </div>
  );
}
