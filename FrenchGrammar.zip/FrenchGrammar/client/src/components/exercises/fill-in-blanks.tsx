import { useState } from "react";
import Feedback from "@/components/ui/feedback";

interface FillInBlanksProps {
  exercise: {
    questions: Array<{
      sentence: string;
      answer: string;
    }>;
  };
  exerciseNumber: number;
}

export default function FillInBlanks({ exercise, exerciseNumber }: FillInBlanksProps) {
  const [answers, setAnswers] = useState<string[]>(new Array(exercise.questions.length).fill(''));
  const [isChecked, setIsChecked] = useState(false);

  const handleInputChange = (index: number, value: string) => {
    if (isChecked) return;
    const newAnswers = [...answers];
    newAnswers[index] = value;
    setAnswers(newAnswers);
  };

  const checkAnswers = () => {
    setIsChecked(true);
  };

  const resetExercise = () => {
    setAnswers(new Array(exercise.questions.length).fill(''));
    setIsChecked(false);
  };

  const correctAnswers = exercise.questions.filter((q, i) => 
    answers[i].trim().toLowerCase() === q.answer.toLowerCase()
  ).length;

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-foreground">
          <i className="fas fa-edit text-accent mr-2"></i>
          Übung {exerciseNumber}: Lücken füllen
        </h3>
        {isChecked && (
          <button
            onClick={resetExercise}
            className="text-sm text-muted-foreground hover:text-primary"
            data-testid="button-reset-fill-blanks"
          >
            <i className="fas fa-redo mr-1"></i>
            Wiederholen
          </button>
        )}
      </div>
      
      <div className="mb-6">
        <p className="text-foreground mb-4">Ergänze den richtigen Artikel:</p>
        <div className="space-y-4">
          {exercise.questions.map((question, index) => {
            const parts = question.sentence.split('___');
            const isCorrect = isChecked && answers[index].trim().toLowerCase() === question.answer.toLowerCase();
            const isIncorrect = isChecked && answers[index].trim().toLowerCase() !== question.answer.toLowerCase();
            
            return (
              <div key={index} className="bg-secondary rounded-lg p-4">
                <p className="text-lg flex items-center">
                  {parts[0]}
                  <input
                    type="text"
                    value={answers[index]}
                    onChange={(e) => handleInputChange(index, e.target.value)}
                    disabled={isChecked}
                    placeholder={isIncorrect ? question.answer : "___"}
                    className={`mx-2 px-2 py-1 border rounded w-20 text-center ${
                      isCorrect
                        ? 'border-green-500 bg-green-50'
                        : isIncorrect
                          ? 'border-red-500 bg-red-50'
                          : 'border-border'
                    }`}
                    data-testid={`input-blank-${index}`}
                  />
                  {parts[1]}
                </p>
              </div>
            );
          })}
        </div>
        
        {!isChecked && (
          <button
            onClick={checkAnswers}
            className="mt-4 bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors"
            data-testid="button-check-blanks"
          >
            Überprüfen
          </button>
        )}

        {isChecked && (
          <Feedback
            isCorrect={correctAnswers === exercise.questions.length}
            message={
              correctAnswers === exercise.questions.length
                ? `✅ Perfekt! Alle ${exercise.questions.length} Antworten sind richtig!`
                : `⚠️ ${correctAnswers}/${exercise.questions.length} richtig. Sieh dir die rot markierten Felder an.`
            }
          />
        )}
      </div>
    </div>
  );
}
