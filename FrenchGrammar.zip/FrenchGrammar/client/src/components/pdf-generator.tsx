import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { TopicData } from '@/data/topics';

interface PDFGeneratorProps {
  topic: TopicData;
  onGenerating?: (generating: boolean) => void;
}

export default function PDFGenerator({ topic, onGenerating }: PDFGeneratorProps) {
  const generatePDF = async () => {
    if (onGenerating) onGenerating(true);
    
    try {
      // Create a temporary div with the content to be converted to PDF
      const tempDiv = document.createElement('div');
      tempDiv.style.position = 'absolute';
      tempDiv.style.left = '-9999px';
      tempDiv.style.width = '800px';
      tempDiv.style.backgroundColor = 'white';
      tempDiv.style.padding = '40px';
      tempDiv.style.fontFamily = 'Arial, sans-serif';
      
      // Generate minimalistic HTML content for the PDF
      tempDiv.innerHTML = `
        <div style="margin-bottom: 30px; text-align: center; border-bottom: 1px solid #000; padding-bottom: 20px;">
          <h1 style="color: #000; font-size: 28px; margin: 0 0 10px 0; font-weight: bold;">
            ${topic.title}
          </h1>
          <h2 style="color: #666; font-size: 18px; margin: 0; font-weight: normal;">
            ${topic.subtitle}
          </h2>
          <div style="margin-top: 15px; padding: 8px 16px; border: 1px solid #000; display: inline-block; font-size: 14px; font-weight: 500;">
            Niveau: ${topic.level.charAt(0).toUpperCase() + topic.level.slice(1)}
          </div>
        </div>
        
        <div style="margin-bottom: 30px;">
          <h3 style="color: #000; font-size: 20px; margin-bottom: 15px; border-left: 2px solid #000; padding-left: 15px;">
            ${topic.explanation.title}
          </h3>
          <div style="padding: 20px; border: 1px solid #ccc; margin-bottom: 20px;">
            <p style="margin: 0; line-height: 1.6; font-size: 14px; color: #333;">
              ${topic.explanation.introduction}
            </p>
          </div>
        </div>
        
        ${topic.explanation.content.map((section, index) => `
          <div style="margin-bottom: 35px; page-break-inside: avoid;">
            <h4 style="color: #000; font-size: 18px; margin-bottom: 12px; border-bottom: 1px solid #ccc; padding-bottom: 8px;">
              ${index + 1}. ${section.title}
            </h4>
            <p style="margin-bottom: 20px; line-height: 1.6; font-size: 14px; color: #333;">
              ${section.description}
            </p>
            
            <div style="margin-bottom: 20px;">
              <h5 style="color: #000; font-size: 16px; margin-bottom: 12px; font-weight: 600;">
                Grammatik-Regeln:
              </h5>
              <table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; border: 1px solid #000;">
                ${section.items.map(item => `
                  <tr style="border-bottom: 1px solid #ccc;">
                    <td style="padding: 12px 15px; background-color: #f5f5f5; font-weight: 600; color: #000; width: 25%; border-right: 1px solid #ccc;">
                      ${item.label}
                    </td>
                    <td style="padding: 12px 15px; color: #000; font-weight: 500; width: 25%; border-right: 1px solid #ccc;">
                      ${item.value}
                    </td>
                    <td style="padding: 12px 15px; color: #333; font-size: 13px; width: 50%;">
                      ${item.explanation || ''}
                    </td>
                  </tr>
                `).join('')}
              </table>
            </div>
            
            ${section.detailedExamples ? `
              <div style="margin-bottom: 20px;">
                <h5 style="color: #000; font-size: 16px; margin-bottom: 12px; font-weight: 600;">
                  Detaillierte Beispiele:
                </h5>
                ${section.detailedExamples.map(example => `
                  <div style="margin-bottom: 15px; padding: 15px; border: 1px solid #ccc;">
                    <div style="font-weight: 600; color: #000; margin-bottom: 5px;">
                      Französisch: ${example.french}
                    </div>
                    <div style="color: #333; margin-bottom: 5px;">
                      Deutsch: ${example.german}
                    </div>
                    <div style="color: #666; font-size: 13px; font-style: italic;">
                      Erklärung: ${example.explanation}
                    </div>
                  </div>
                `).join('')}
              </div>
            ` : ''}
            
            ${section.examples ? `
              <div style="border: 1px solid #ccc; padding: 15px;">
                <h5 style="color: #000; font-size: 14px; margin-bottom: 8px; font-weight: 600;">
                  Weitere Beispiele:
                </h5>
                <p style="margin: 0; color: #333; font-size: 13px; line-height: 1.5;">
                  ${section.examples}
                </p>
              </div>
            ` : ''}
            
            ${section.rules ? `
              <div style="margin-top: 15px; border: 1px solid #ccc; padding: 15px;">
                <h5 style="color: #000; font-size: 14px; margin-bottom: 10px; font-weight: 600;">
                  Wichtige Regeln zu beachten:
                </h5>
                <ul style="margin: 0; padding-left: 20px; color: #333; font-size: 13px;">
                  ${section.rules.map(rule => `<li style="margin-bottom: 5px; line-height: 1.4;">${rule}</li>`).join('')}
                </ul>
              </div>
            ` : ''}
          </div>
        `).join('')}
        
        <div style="margin-top: 40px; padding: 20px; border: 1px solid #000;">
          <h4 style="color: #000; font-size: 16px; margin-bottom: 12px;">
            Übungsübersicht zu diesem Thema:
          </h4>
          <ul style="margin: 0; padding-left: 20px; color: #333; font-size: 13px;">
            <li style="margin-bottom: 8px;">Multiple-Choice-Fragen zur Vertiefung</li>
            <li style="margin-bottom: 8px;">Lückentexte zum aktiven Üben</li>
            <li style="margin-bottom: 8px;">Drag-and-Drop-Übungen für spielerisches Lernen</li>
            <li style="margin-bottom: 8px;">Zuordnungsaufgaben für besseres Verständnis</li>
          </ul>
        </div>
        
        <div style="margin-top: 30px; text-align: center; padding: 15px; border-top: 1px solid #000; color: #666; font-size: 12px;">
          <p style="margin: 0;">
            Französisch Grammatik Lernen - 7. Klasse<br>
            Erstellt am: ${new Date().toLocaleDateString('de-DE')} | 
            Thema: ${topic.title}
          </p>
        </div>
      `;
      
      document.body.appendChild(tempDiv);
      
      // Create canvas from the div
      const canvas = await html2canvas(tempDiv, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        width: 800,
        height: tempDiv.scrollHeight,
        scrollX: 0,
        scrollY: 0
      });
      
      // Clean up
      document.body.removeChild(tempDiv);
      
      // Create PDF
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210; // A4 width in mm
      const pageHeight = 295; // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      
      let position = 0;
      
      // Add image to PDF
      pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      
      // Add new pages if content is longer than one page
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      // Download the PDF
      const fileName = `Französisch_Grammatik_${topic.title.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
      pdf.save(fileName);
      
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Fehler beim Erstellen der PDF. Bitte versuchen Sie es erneut.');
    } finally {
      if (onGenerating) onGenerating(false);
    }
  };

  return (
    <button
      onClick={generatePDF}
      className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium text-sm"
      data-testid="download-pdf-button"
    >
      <i className="fas fa-file-pdf"></i>
      PDF Erklärung herunterladen
    </button>
  );
}