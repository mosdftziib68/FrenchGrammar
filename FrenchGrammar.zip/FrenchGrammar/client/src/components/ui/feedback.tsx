interface FeedbackProps {
  isCorrect: boolean;
  message: string;
}

export default function Feedback({ isCorrect, message }: FeedbackProps) {
  return (
    <div className="mt-4">
      <div className={`p-4 rounded-lg ${
        isCorrect 
          ? 'bg-green-100 border border-green-200' 
          : 'bg-red-100 border border-red-200'
      }`}>
        <p className={`${
          isCorrect ? 'text-green-800' : 'text-red-800'
        }`}>
          {message}
        </p>
      </div>
    </div>
  );
}
